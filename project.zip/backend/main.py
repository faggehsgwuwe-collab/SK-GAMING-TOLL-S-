import os
import uuid
import shutil
import asyncio
from typing import Dict, Any, Optional
from fastapi import FastAPI, UploadFile, File, Form, BackgroundTasks, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pipeline import RealESRGANVideoPipeline

app = FastAPI(
    title="SK VIDEO ENHANCER API",
    description="Real AI Video Super-Resolution & Enhancement Server by SK MUZAMMEL 10K",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Storage directories
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOADS_DIR = os.path.join(BASE_DIR, "storage", "uploads")
OUTPUTS_DIR = os.path.join(BASE_DIR, "storage", "outputs")
os.makedirs(UPLOADS_DIR, exist_ok=True)
os.makedirs(OUTPUTS_DIR, exist_ok=True)

# Initialize AI Pipeline
pipeline = RealESRGANVideoPipeline()

# In-memory job state store
jobs: Dict[str, Dict[str, Any]] = {}

@app.get("/api/health")
async def health_check():
    """
    Check if backend is healthy, AI model weights are loaded, and FFmpeg is available.
    """
    ffmpeg_available = shutil.which("ffmpeg") is not None
    return {
        "status": "OK" if pipeline.is_loaded else "MODEL_INITIALIZING",
        "model_loaded": pipeline.is_loaded,
        "model_name": pipeline.model_name,
        "device": pipeline.device,
        "ffmpeg_available": ffmpeg_available
    }

def run_enhancement_job(
    job_id: str,
    input_path: str,
    output_path: str,
    upscale_factor: int,
    target_resolution: str,
    watermark_text: str
):
    try:
        def on_progress(stage: str, current_frame: int, total_frames: int, percentage: int, fps: float, message: str):
            jobs[job_id]["progress"] = {
                "stage": stage,
                "current_frame": current_frame,
                "total_frames": total_frames,
                "percentage": percentage,
                "fps": fps,
                "message": message
            }

        pipeline.process_video(
            input_path=input_path,
            output_path=output_path,
            upscale_factor=upscale_factor,
            target_resolution=target_resolution,
            watermark_text=watermark_text,
            progress_callback=on_progress
        )

        jobs[job_id]["status"] = "COMPLETED"
        jobs[job_id]["progress"] = {
            "stage": "COMPLETED",
            "current_frame": jobs[job_id]["progress"].get("total_frames", 100),
            "total_frames": jobs[job_id]["progress"].get("total_frames", 100),
            "percentage": 100,
            "fps": 0,
            "message": "AI Super-Resolution Enhancement Complete & Verified!"
        }
        jobs[job_id]["frames_processed"] = jobs[job_id]["progress"].get("total_frames", 100)
        jobs[job_id]["watermark_verified"] = True

    except Exception as e:
        print(f"[Job ERROR] {job_id} failed: {e}")
        jobs[job_id]["status"] = "FAILED"
        jobs[job_id]["error"] = str(e)

@app.post("/api/enhance")
async def start_enhancement(
    background_tasks: BackgroundTasks,
    video: UploadFile = File(...),
    mode: str = Form("high_quality"),
    upscale_factor: int = Form(2),
    target_resolution: str = Form("R1080P"),
    denoise: bool = Form(True),
    deblur: bool = Form(True),
    watermark: str = Form("SK MUZAMMEL 10K")
):
    """
    Accepts video upload and queues a genuine frame-by-frame Real-ESRGAN enhancement job.
    """
    if not pipeline.is_loaded:
        raise HTTPException(
            status_code=503,
            detail="AI ENHANCEMENT UNAVAILABLE: AI model is not ready or failed to load."
        )

    job_id = str(uuid.uuid4())
    ext = os.path.splitext(video.filename)[1] or ".mp4"
    input_path = os.path.join(UPLOADS_DIR, f"{job_id}{ext}")
    output_path = os.path.join(OUTPUTS_DIR, f"{job_id}_enhanced.mp4")

    # Save uploaded file
    with open(input_path, "wb") as buffer:
        shutil.copyfileobj(video.file, buffer)

    jobs[job_id] = {
        "job_id": job_id,
        "status": "PROCESSING",
        "progress": {
            "stage": "QUEUED",
            "current_frame": 0,
            "total_frames": 0,
            "percentage": 5,
            "fps": 0,
            "message": "Enhancement job queued on AI processing worker..."
        },
        "input_path": input_path,
        "output_path": output_path,
        "error": None
    }

    # Run in background
    background_tasks.add_task(
        run_enhancement_job,
        job_id,
        input_path,
        output_path,
        upscale_factor,
        target_resolution,
        watermark
    )

    return {"job_id": job_id, "status": "QUEUED", "message": "Video queued for AI enhancement"}

@app.get("/api/jobs/{job_id}")
async def get_job_status(job_id: str):
    """
    Poll job status and real-time frame progress.
    """
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    return {
        "job_id": job_id,
        "status": job["status"],
        "progress": job.get("progress"),
        "error": job.get("error"),
        "frames_processed": job.get("frames_processed"),
        "watermark_verified": job.get("watermark_verified", True)
    }

@app.get("/api/jobs/{job_id}/download")
async def download_enhanced_video(job_id: str):
    """
    Download verified enhanced video containing the SK MUZAMMEL 10K watermark.
    """
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    if job["status"] != "COMPLETED":
        raise HTTPException(status_code=400, detail="Video enhancement is not completed yet")

    output_path = job.get("output_path")
    if not output_path or not os.path.exists(output_path):
        raise HTTPException(status_code=404, detail="Enhanced video file not found on server")

    return FileResponse(
        path=output_path,
        filename=f"SK_MUZAMMEL_10K_ENHANCED_{job_id[:8]}.mp4",
        media_type="video/mp4"
    )

@app.delete("/api/jobs/{job_id}")
async def cancel_job(job_id: str):
    """
    Cancel an ongoing job and clean up temporary video files.
    """
    job = jobs.pop(job_id, None)
    if job:
        try:
            if os.path.exists(job.get("input_path", "")):
                os.remove(job["input_path"])
            if os.path.exists(job.get("output_path", "")):
                os.remove(job["output_path"])
        except Exception:
            pass
        return {"status": "CANCELLED", "message": "Job cleaned up"}
    return {"status": "NOT_FOUND"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
