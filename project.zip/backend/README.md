# SK VIDEO ENHANCER — AI Backend & Android Setup Guide

**Brand Name:** SK VIDEO ENHANCER  
**Official Watermark:** `SK MUZAMMEL 10K`  
**Core Model:** Real-ESRGAN (RealESRGAN_x4plus / RealESRGAN_x2plus) with PyTorch & FFmpeg Frame Processing Pipeline

---

## Architecture Overview

SK VIDEO ENHANCER uses a genuine frame-by-frame deep neural super-resolution architecture:
1. **FFmpeg Frame Ingestion**: Demuxes video and extracts uncompressed frames with timestamps.
2. **Audio Track Extraction**: Isolates AAC/MP3 audio stream for preservation and synchronization.
3. **AI Super-Resolution Processing**: Runs individual frames through the Real-ESRGAN neural network to reconstruct micro-textures and high-frequency edge acuity.
4. **Watermark Injection**: Burns `SK MUZAMMEL 10K` into the bottom-right corner at 28% opacity via FFmpeg `drawtext`.
5. **Video Encoding & Audio Remuxing**: Synthesizes the enhanced frames and synchronized audio into a pristine MP4 container with verification check.

---

## 1. Quick Start (Local / GPU Server)

### Prerequisites
- Python 3.10 or higher
- FFmpeg (`sudo apt install ffmpeg` or `brew install ffmpeg`)
- NVIDIA GPU with CUDA 11.8+ (optional, CPU mode also supported)

### Setup & Run
```bash
cd backend
pip install -r requirements.txt
./run_server.sh
```
The server will start at: `http://0.0.0.0:8000`.

API Documentation (Swagger UI): `http://localhost:8000/docs`

---

## 2. Docker Deployment (Recommended for Cloud VPS)

```bash
cd backend
docker compose up -d
```
This automatically downloads CUDA 12.1 runtime, PyTorch, FFmpeg, and initializes the `RealESRGAN_x4plus.pth` model weights.

---

## 3. Cloud GPU Deployment (RunPod / Google Colab / HuggingFace Spaces)

### Deploying to RunPod:
1. Select a GPU Pod with RTX 3090, RTX 4090, or A4000.
2. Clone this repository onto the pod.
3. Expose port `8000`.
4. Run:
   ```bash
   cd backend
   pip install -r requirements.txt
   python3 -m uvicorn main:app --host 0.0.0.0 --port 8000
   ```
5. Use the public RunPod Proxy URL (e.g., `https://xxxxx-8000.proxy.runpod.net`) in the Android app Settings.

---

## 4. Connecting Android App to the Backend

1. Open **SK VIDEO ENHANCER** on your Android device.
2. Navigate to the **Settings** tab.
3. Switch Processing Engine to **Custom GPU Server (FastAPI + Real-ESRGAN)**.
4. Enter your backend URL:
   - For Android Emulator: `http://10.0.2.2:8000`
   - For LAN WiFi testing: `http://192.168.x.x:8000`
   - For Cloud server: `https://your-domain-or-proxy.com`
5. Tap **Test Backend Connection**. A green badge will confirm `PyTorch & Real-ESRGAN Ready`.

*Note: If no server is running, the app also features an **Embedded On-Device AI Engine** that runs offline on your phone!*

---

## 5. Building the Android APK

To compile the Android APK:
```bash
gradle :app:assembleRelease
```
Or for debug testing:
```bash
gradle :app:assembleDebug
```
The APK will be generated at:
`app/build/outputs/apk/release/app-release.apk`
