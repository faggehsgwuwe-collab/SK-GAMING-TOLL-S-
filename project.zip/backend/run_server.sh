#!/usr/bin/env bash
set -e

echo "=== Starting SK VIDEO ENHANCER AI Server ==="
echo "Brand: SK VIDEO ENHANCER"
echo "Watermark: SK MUZAMMEL 10K"

python3 -m pip install -r requirements.txt
python3 -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
