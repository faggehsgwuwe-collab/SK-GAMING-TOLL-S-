"""
Watermark burning engine for SK VIDEO ENHANCER
Burn-in watermark: 'SK MUZAMMEL 10K'
Appearance: 28% opacity, light white/gray, bottom-right corner with safe margin.
"""

def get_ffmpeg_watermark_filter(
    text: str = "SK MUZAMMEL 10K",
    opacity: float = 0.28,
    font_size_ratio: float = 0.024
) -> str:
    """
    Constructs an FFmpeg drawtext filter string that scales relative to video resolution.
    Bottom-right corner with responsive margin.
    """
    # Escapes for ffmpeg drawtext filter
    escaped_text = text.replace(":", "\\:").replace("'", "\\'")
    
    # Dynamic font size: e.g. 24px on 720p, 36px on 1080p, 72px on 4K
    font_expr = f"max(18, w * {font_size_ratio})"
    margin_x = "w * 0.035"
    margin_y = "h * 0.04"
    
    filter_str = (
        f"drawtext=text='{escaped_text}':"
        f"fontsize={font_expr}:"
        f"fontcolor=white@{opacity}:"
        f"x=w-tw-({margin_x}):"
        f"y=h-th-({margin_y}):"
        f"shadowcolor=black@0.4:shadowx=2:shadowy=2"
    )
    return filter_str
