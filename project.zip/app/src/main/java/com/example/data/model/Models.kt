package com.example.data.model

enum class EnhancementMode(val id: String) {
    BASIC("basic"),
    HIGH_QUALITY("high_quality")
}

enum class UpscaleFactor(val factor: Int, val label: String) {
    X1(1, "1x (Native)"),
    X2(2, "2x (Super-Res)"),
    X4(4, "4x (Ultra-Res)")
}

enum class TargetResolution(val width: Int, val height: Int, val label: String) {
    R720P(1280, 720, "720p HD"),
    R1080P(1920, 1080, "1080p FHD"),
    R4K(3840, 2160, "4K UHD")
}

enum class EngineMode {
    LOCAL_EMBEDDED,
    REMOTE_FASTAPI
}

enum class AppLanguage {
    ENGLISH,
    BENGALI
}

data class EnhancementOptions(
    val mode: EnhancementMode = EnhancementMode.HIGH_QUALITY,
    val upscaleFactor: UpscaleFactor = UpscaleFactor.X2,
    val targetResolution: TargetResolution = TargetResolution.R1080P,
    val denoise: Boolean = true,
    val deblur: Boolean = true,
    val frameInterpolation: Boolean = false,
    val watermarkText: String = "SK MUZAMMEL 10K",
    val watermarkOpacity: Float = 0.28f
)

data class VideoMetadata(
    val uriString: String,
    val fileName: String,
    val fileSizeBytes: Long,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val frameRate: Float,
    val hasAudio: Boolean,
    val mimeType: String
) {
    val durationFormatted: String
        get() {
            val seconds = (durationMs / 1000) % 60
            val minutes = (durationMs / (1000 * 60)) % 60
            val hours = durationMs / (1000 * 60 * 60)
            return if (hours > 0) {
                String.format("%02d:%02d:%02d", hours, minutes, seconds)
            } else {
                String.format("%02d:%02d", minutes, seconds)
            }
        }

    val sizeFormatted: String
        get() {
            val kb = fileSizeBytes / 1024.0
            val mb = kb / 1024.0
            return if (mb >= 1.0) {
                String.format("%.1f MB", mb)
            } else {
                String.format("%.0f KB", kb)
            }
        }

    val resolutionFormatted: String
        get() = "${width}x${height}"
}

enum class ProcessingStage {
    IDLE,
    ANALYZING,
    VERIFYING_MODEL,
    EXTRACTING_FRAMES,
    AI_ENHANCING_FRAMES,
    SYNCHRONIZING_AUDIO,
    BURNING_WATERMARK,
    VERIFYING_OUTPUT,
    COMPLETED,
    FAILED
}

data class ProcessingProgress(
    val stage: ProcessingStage = ProcessingStage.IDLE,
    val currentFrame: Int = 0,
    val totalFrames: Int = 0,
    val percentage: Int = 0,
    val fps: Float = 0f,
    val statusMessage: String = "",
    val error: String? = null
)

data class EnhancedResult(
    val id: String,
    val originalVideoUri: String,
    val enhancedVideoUri: String,
    val originalThumbnailPath: String?,
    val enhancedThumbnailPath: String?,
    val originalWidth: Int,
    val originalHeight: Int,
    val enhancedWidth: Int,
    val enhancedHeight: Int,
    val originalSizeBytes: Long,
    val enhancedSizeBytes: Long,
    val framesProcessed: Int,
    val durationMs: Long,
    val timestamp: Long,
    val options: EnhancementOptions,
    val verifiedWatermark: Boolean = true,
    val isVerifiedAiEnhanced: Boolean = true
)
