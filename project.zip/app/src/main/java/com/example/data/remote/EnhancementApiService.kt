package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

@JsonClass(generateAdapter = true)
data class EnhanceJobResponse(
    @Json(name = "job_id") val jobId: String,
    @Json(name = "status") val status: String,
    @Json(name = "message") val message: String? = null
)

@JsonClass(generateAdapter = true)
data class ProgressDetail(
    @Json(name = "stage") val stage: String,
    @Json(name = "current_frame") val currentFrame: Int,
    @Json(name = "total_frames") val totalFrames: Int,
    @Json(name = "percentage") val percentage: Int,
    @Json(name = "fps") val fps: Float = 0f,
    @Json(name = "message") val message: String? = null
)

@JsonClass(generateAdapter = true)
data class JobStatusResponse(
    @Json(name = "job_id") val jobId: String,
    @Json(name = "status") val status: String, // "QUEUED", "PROCESSING", "COMPLETED", "FAILED"
    @Json(name = "progress") val progress: ProgressDetail?,
    @Json(name = "error") val error: String? = null,
    @Json(name = "original_width") val originalWidth: Int? = null,
    @Json(name = "original_height") val originalHeight: Int? = null,
    @Json(name = "enhanced_width") val enhancedWidth: Int? = null,
    @Json(name = "enhanced_height") val enhancedHeight: Int? = null,
    @Json(name = "duration_ms") val durationMs: Long? = null,
    @Json(name = "frames_processed") val framesProcessed: Int? = null,
    @Json(name = "watermark_verified") val watermarkVerified: Boolean? = true
)

@JsonClass(generateAdapter = true)
data class HealthCheckResponse(
    @Json(name = "status") val status: String,
    @Json(name = "model_loaded") val modelLoaded: Boolean,
    @Json(name = "model_name") val modelName: String,
    @Json(name = "device") val device: String,
    @Json(name = "ffmpeg_available") val ffmpegAvailable: Boolean
)

interface EnhancementApiService {
    @GET("api/health")
    suspend fun checkHealth(): HealthCheckResponse

    @Multipart
    @POST("api/enhance")
    suspend fun startEnhance(
        @Part video: MultipartBody.Part,
        @Part("mode") mode: RequestBody,
        @Part("upscale_factor") upscaleFactor: RequestBody,
        @Part("target_resolution") targetResolution: RequestBody,
        @Part("denoise") denoise: RequestBody,
        @Part("deblur") deblur: RequestBody,
        @Part("watermark") watermark: RequestBody
    ): EnhanceJobResponse

    @GET("api/jobs/{job_id}")
    suspend fun getJobStatus(@Path("job_id") jobId: String): JobStatusResponse

    @Streaming
    @GET("api/jobs/{job_id}/download")
    suspend fun downloadEnhancedVideo(@Path("job_id") jobId: String): Response<ResponseBody>

    @DELETE("api/jobs/{job_id}")
    suspend fun cancelJob(@Path("job_id") jobId: String): Response<Unit>
}
