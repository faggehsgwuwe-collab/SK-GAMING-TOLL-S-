package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface EnhancementDao {
    @Query("SELECT * FROM enhancement_history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<EnhancementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: EnhancementEntity)

    @Query("DELETE FROM enhancement_history WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM enhancement_history")
    suspend fun clearAll()
}
