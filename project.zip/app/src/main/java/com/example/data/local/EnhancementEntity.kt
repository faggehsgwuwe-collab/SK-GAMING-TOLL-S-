package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "enhancement_history")
data class EnhancementEntity(
    @PrimaryKey
    val id: String,
    val fileName: String,
    val originalVideoUri: String,
    val enhancedVideoUri: String,
    val originalThumbnailPath: String?,
    val enhancedThumbnailPath: String?,
    val originalWidth: Int,
    val originalHeight: Int,
    val enhancedWidth: Int,
    val enhancedHeight: Int,
    val originalSizeBytes: Long,
    val enhancedSizeBytes: Long,
    val framesProcessed: Int,
    val durationMs: Long,
    val timestamp: Long,
    val mode: String,
    val upscaleFactor: Int,
    val targetResolution: String,
    val watermarkText: String,
    val isVerified: Boolean
)
