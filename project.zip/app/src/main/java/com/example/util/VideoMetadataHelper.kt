package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import com.example.data.model.VideoMetadata
import java.io.File
import java.io.FileOutputStream

object VideoMetadataHelper {

    fun extractMetadata(context: Context, uri: Uri): Result<VideoMetadata> {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)

            val widthStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
            val heightStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            val rotationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
            val hasAudioStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)
            val mimeTypeStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE) ?: "video/mp4"

            var width = widthStr?.toIntOrNull() ?: 0
            var height = heightStr?.toIntOrNull() ?: 0
            val rotation = rotationStr?.toIntOrNull() ?: 0
            if (rotation == 90 || rotation == 270) {
                val temp = width
                width = height
                height = temp
            }

            val durationMs = durationStr?.toLongOrNull() ?: 0L
            val hasAudio = hasAudioStr != null && hasAudioStr.equals("yes", ignoreCase = true)

            // Extract file name and size
            val (fileName, fileSizeBytes) = queryFileNameAndSize(context, uri)

            if (width <= 0 || height <= 0 || durationMs <= 0) {
                return Result.failure(IllegalArgumentException("Invalid or corrupted video dimensions/duration"))
            }

            // Estimate or calculate frame rate
            val frameRate = estimateFps(retriever, durationMs)

            val meta = VideoMetadata(
                uriString = uri.toString(),
                fileName = fileName,
                fileSizeBytes = fileSizeBytes,
                durationMs = durationMs,
                width = width,
                height = height,
                frameRate = frameRate,
                hasAudio = hasAudio,
                mimeType = mimeTypeStr
            )
            Result.success(meta)
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }
    }

    fun extractThumbnail(context: Context, uri: Uri, timeUs: Long = 1000000L): Bitmap? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        } catch (e: Exception) {
            null
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }
    }

    fun saveBitmapToCache(context: Context, bitmap: Bitmap, prefix: String): String? {
        return try {
            val file = File(context.cacheDir, "${prefix}_${System.currentTimeMillis()}.jpg")
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
            }
            file.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    private fun queryFileNameAndSize(context: Context, uri: Uri): Pair<String, Long> {
        var name = "video.mp4"
        var size = 0L

        if (uri.scheme == "content") {
            try {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (cursor.moveToFirst()) {
                        if (nameIdx != -1) name = cursor.getString(nameIdx) ?: name
                        if (sizeIdx != -1) size = cursor.getLong(sizeIdx)
                    }
                }
            } catch (_: Exception) {}
        } else if (uri.scheme == "file") {
            uri.path?.let {
                val f = File(it)
                name = f.name
                size = f.length()
            }
        }

        if (size == 0L) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    size = stream.available().toLong()
                }
            } catch (_: Exception) {}
        }

        return Pair(name, size)
    }

    private fun estimateFps(retriever: MediaMetadataRetriever, durationMs: Long): Float {
        val captureRateStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)
        val rate = captureRateStr?.toFloatOrNull()
        if (rate != null && rate > 0) return rate

        // Fallback default standard fps
        return 30.0f
    }
}
