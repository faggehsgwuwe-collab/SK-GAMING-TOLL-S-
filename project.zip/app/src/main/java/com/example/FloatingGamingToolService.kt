package com.example

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.CountDownTimer
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.hypot

class FloatingGamingToolService : Service() {

    companion object {
        const val CHANNEL_ID = "sk_gaming_overlay_channel"
        const val NOTIFICATION_ID = 8801

        const val ACTION_START = "com.example.action.START_TOOL"
        const val ACTION_STOP = "com.example.action.STOP_TOOL"
        const val ACTION_SHOW_BUBBLE = "com.example.action.SHOW_BUBBLE"

        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning

        private val _isCrosshairActive = MutableStateFlow(false)
        val isCrosshairActive: StateFlow<Boolean> = _isCrosshairActive
    }

    private lateinit var windowManager: WindowManager

    // Views
    private var bubbleView: View? = null
    private var toolboxView: View? = null
    private var crosshairView: View? = null

    // Layout Params
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var toolboxParams: WindowManager.LayoutParams
    private lateinit var crosshairParams: WindowManager.LayoutParams

    // States
    private var isToolboxExpanded = false
    private var isHiddenTemporarily = false
    private var currentCrosshairColor = Color.parseColor("#00FF66")

    // Tools
    private var wakeLock: PowerManager.WakeLock? = null
    private var zoneTimer: CountDownTimer? = null
    private var timerSecondsLeft = 120
    private var isTimerRunning = false

    private val handler = Handler(Looper.getMainLooper())
    private var unhideRunnable: Runnable? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForegroundServiceWithNotification()

        if (Settings.canDrawOverlays(this)) {
            initBubbleView()
            initToolboxView()
            initCrosshairView()
            _isRunning.value = true
        } else {
            Toast.makeText(this, "Overlay permission required for SK Gaming Tool", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_SHOW_BUBBLE -> {
                restoreFromHidden()
            }
        }
        return START_STICKY
    }

    private fun startForegroundServiceWithNotification() {
        val channelName = getString(R.string.overlay_channel_name)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                channelName,
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.overlay_channel_desc)
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }

        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            this.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpen = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, FloatingGamingToolService::class.java).apply {
            action = ACTION_STOP
        }
        val pendingStop = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val restoreIntent = Intent(this, FloatingGamingToolService::class.java).apply {
            action = ACTION_SHOW_BUBBLE
        }
        val pendingRestore = PendingIntent.getService(
            this,
            2,
            restoreIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SK GAMING TOOL")
            .setContentText("Movable floating tool active over Free Fire")
            .setSmallIcon(R.drawable.ic_sk_gaming_logo)
            .setContentIntent(pendingOpen)
            .addAction(R.drawable.ic_drag_handle, "Show Overlay", pendingRestore)
            .addAction(R.drawable.ic_close_btn, "Stop Tool", pendingStop)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun initBubbleView() {
        val inflater = LayoutInflater.from(this)
        bubbleView = inflater.inflate(R.layout.layout_floating_bubble, null)

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        bubbleParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 300
        }

        setupBubbleTouchListener()
        try {
            windowManager.addView(bubbleView, bubbleParams)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setupBubbleTouchListener() {
        bubbleView?.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = bubbleParams.x
                        initialY = bubbleParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        bubbleParams.x = initialX + (event.rawX - initialTouchX).toInt()
                        bubbleParams.y = initialY + (event.rawY - initialTouchY).toInt()
                        try {
                            windowManager.updateViewLayout(bubbleView, bubbleParams)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val diffX = event.rawX - initialTouchX
                        val diffY = event.rawY - initialTouchY
                        val distance = hypot(diffX.toDouble(), diffY.toDouble())

                        // Click detected if finger moved less than 15 pixels
                        if (distance < 20) {
                            vibrateDevice(35)
                            toggleToolbox()
                        }
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun initToolboxView() {
        val inflater = LayoutInflater.from(this)
        toolboxView = inflater.inflate(R.layout.layout_floating_toolbox, null)

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        toolboxParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 200
        }

        setupToolboxInteractions()
        toolboxView?.visibility = View.GONE

        try {
            windowManager.addView(toolboxView, toolboxParams)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setupToolboxInteractions() {
        val root = toolboxView ?: return

        // 1. Drag header handler for moving the entire toolbox
        val dragHeader = root.findViewById<View>(R.id.toolbox_drag_header)
        dragHeader.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = toolboxParams.x
                        initialY = toolboxParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        toolboxParams.x = initialX + (event.rawX - initialTouchX).toInt()
                        toolboxParams.y = initialY + (event.rawY - initialTouchY).toInt()
                        try {
                            windowManager.updateViewLayout(toolboxView, toolboxParams)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                        return true
                    }
                }
                return false
            }
        })

        // 2. Window Controls: Minimize, Hide, Close
        root.findViewById<ImageButton>(R.id.btn_minimize).setOnClickListener {
            vibrateDevice(25)
            minimizeToolbox()
        }

        root.findViewById<ImageButton>(R.id.btn_hide).setOnClickListener {
            vibrateDevice(25)
            hideOverlayStealthMode()
        }

        root.findViewById<ImageButton>(R.id.btn_close).setOnClickListener {
            vibrateDevice(40)
            Toast.makeText(this, "SK Gaming Tool stopped", Toast.LENGTH_SHORT).show()
            stopSelf()
        }

        // 3. Tab Navigation
        val tabShortcuts = root.findViewById<Button>(R.id.tab_shortcuts)
        val tabCrosshair = root.findViewById<Button>(R.id.tab_crosshair)
        val tabTools = root.findViewById<Button>(R.id.tab_tools)
        val tabPip = root.findViewById<Button>(R.id.tab_pip)

        val panelShortcuts = root.findViewById<LinearLayout>(R.id.panel_shortcuts)
        val panelCrosshair = root.findViewById<LinearLayout>(R.id.panel_crosshair)
        val panelTools = root.findViewById<LinearLayout>(R.id.panel_tools)
        val panelPip = root.findViewById<LinearLayout>(R.id.panel_pip)

        fun selectTab(activeTab: Button, activePanel: LinearLayout) {
            vibrateDevice(20)
            listOf(tabShortcuts, tabCrosshair, tabTools, tabPip).forEach { tab ->
                if (tab == activeTab) {
                    tab.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#00FF66"))
                    tab.setTextColor(Color.BLACK)
                } else {
                    tab.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#1B2636"))
                    tab.setTextColor(Color.parseColor("#8B949E"))
                }
            }
            listOf(panelShortcuts, panelCrosshair, panelTools, panelPip).forEach { panel ->
                panel.visibility = if (panel == activePanel) View.VISIBLE else View.GONE
            }
        }

        tabShortcuts.setOnClickListener { selectTab(tabShortcuts, panelShortcuts) }
        tabCrosshair.setOnClickListener { selectTab(tabCrosshair, panelCrosshair) }
        tabTools.setOnClickListener { selectTab(tabTools, panelTools) }
        tabPip.setOnClickListener { selectTab(tabPip, panelPip) }

        // 4. App Shortcuts
        root.findViewById<View>(R.id.btn_app_freefire).setOnClickListener {
            vibrateDevice(30)
            AppLauncherHelper.launchAppOrFallback(
                this,
                AppLauncherHelper.PKG_FREE_FIRE,
                "https://ff.garena.com",
                "Free Fire"
            )
        }

        root.findViewById<View>(R.id.btn_app_whatsapp).setOnClickListener {
            vibrateDevice(30)
            AppLauncherHelper.launchAppOrFallback(
                this,
                AppLauncherHelper.PKG_WHATSAPP,
                "https://web.whatsapp.com",
                "WhatsApp"
            )
        }

        root.findViewById<View>(R.id.btn_app_youtube).setOnClickListener {
            vibrateDevice(30)
            AppLauncherHelper.launchAppOrFallback(
                this,
                AppLauncherHelper.PKG_YOUTUBE,
                "https://m.youtube.com",
                "YouTube"
            )
        }

        root.findViewById<View>(R.id.btn_app_messenger).setOnClickListener {
            vibrateDevice(30)
            AppLauncherHelper.launchAppOrFallback(
                this,
                AppLauncherHelper.PKG_MESSENGER,
                "https://m.me",
                "Messenger"
            )
        }

        root.findViewById<View>(R.id.btn_app_chrome).setOnClickListener {
            vibrateDevice(30)
            AppLauncherHelper.launchAppOrFallback(
                this,
                AppLauncherHelper.PKG_CHROME,
                "https://www.google.com",
                "Chrome"
            )
        }

        root.findViewById<View>(R.id.btn_app_discord).setOnClickListener {
            vibrateDevice(30)
            AppLauncherHelper.launchAppOrFallback(
                this,
                AppLauncherHelper.PKG_DISCORD,
                "https://discord.com",
                "Discord"
            )
        }

        // 5. Crosshair Controls
        val switchCrosshair = root.findViewById<Switch>(R.id.switch_crosshair)
        switchCrosshair.setOnCheckedChangeListener { _, isChecked ->
            vibrateDevice(25)
            setCrosshairVisibility(isChecked)
        }

        root.findViewById<Button>(R.id.btn_color_green).setOnClickListener {
            updateCrosshairColor(Color.parseColor("#00FF66"))
        }
        root.findViewById<Button>(R.id.btn_color_red).setOnClickListener {
            updateCrosshairColor(Color.parseColor("#FF2A55"))
        }
        root.findViewById<Button>(R.id.btn_color_cyan).setOnClickListener {
            updateCrosshairColor(Color.parseColor("#00E5FF"))
        }
        root.findViewById<Button>(R.id.btn_color_yellow).setOnClickListener {
            updateCrosshairColor(Color.parseColor("#FFD600"))
        }

        // 6. Gaming Tools: WakeLock & Zone Timer
        val switchWakeLock = root.findViewById<Switch>(R.id.switch_wake_lock)
        switchWakeLock.setOnCheckedChangeListener { _, isChecked ->
            vibrateDevice(25)
            setWakeLockActive(isChecked)
        }

        val tvZoneTimer = root.findViewById<TextView>(R.id.tv_zone_timer)
        val btnTimerToggle = root.findViewById<Button>(R.id.btn_timer_toggle)
        btnTimerToggle.setOnClickListener {
            vibrateDevice(30)
            if (isTimerRunning) {
                stopZoneTimer(tvZoneTimer, btnTimerToggle)
            } else {
                startZoneTimer(tvZoneTimer, btnTimerToggle)
            }
        }

        // 7. PiP Launch Button
        root.findViewById<Button>(R.id.btn_launch_pip).setOnClickListener {
            vibrateDevice(40)
            val pipIntent = Intent(this, PipGamingCompanionActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(pipIntent)
            minimizeToolbox()
        }
    }

    private fun initCrosshairView() {
        val inflater = LayoutInflater.from(this)
        crosshairView = inflater.inflate(R.layout.layout_crosshair_overlay, null)

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        crosshairParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        crosshairView?.visibility = View.GONE

        try {
            windowManager.addView(crosshairView, crosshairParams)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun toggleToolbox() {
        if (isToolboxExpanded) {
            minimizeToolbox()
        } else {
            expandToolbox()
        }
    }

    private fun expandToolbox() {
        isToolboxExpanded = true
        bubbleView?.visibility = View.GONE
        // Position toolbox near the bubble's position
        toolboxParams.x = (bubbleParams.x - 20).coerceAtLeast(10)
        toolboxParams.y = (bubbleParams.y - 40).coerceAtLeast(50)
        try {
            windowManager.updateViewLayout(toolboxView, toolboxParams)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        toolboxView?.visibility = View.VISIBLE
    }

    private fun minimizeToolbox() {
        isToolboxExpanded = false
        toolboxView?.visibility = View.GONE
        bubbleView?.visibility = View.VISIBLE
    }

    private fun hideOverlayStealthMode() {
        isHiddenTemporarily = true
        isToolboxExpanded = false
        toolboxView?.visibility = View.GONE
        bubbleView?.visibility = View.GONE

        Toast.makeText(this, "SK Gaming Tool hidden for 15s (Tap notification to unhide)", Toast.LENGTH_SHORT).show()

        unhideRunnable?.let { handler.removeCallbacks(it) }
        unhideRunnable = Runnable {
            restoreFromHidden()
        }
        handler.postDelayed(unhideRunnable!!, 15000)
    }

    private fun restoreFromHidden() {
        unhideRunnable?.let { handler.removeCallbacks(it) }
        isHiddenTemporarily = false
        isToolboxExpanded = false
        toolboxView?.visibility = View.GONE
        bubbleView?.visibility = View.VISIBLE
    }

    private fun setCrosshairVisibility(visible: Boolean) {
        _isCrosshairActive.value = visible
        crosshairView?.visibility = if (visible) View.VISIBLE else View.GONE
    }

    private fun updateCrosshairColor(color: Int) {
        currentCrosshairColor = color
        vibrateDevice(20)
        val root = crosshairView ?: return
        root.findViewById<View>(R.id.crosshair_dot).backgroundTintList = ColorStateList.valueOf(color)
        root.findViewById<View>(R.id.crosshair_top).setBackgroundColor(color)
        root.findViewById<View>(R.id.crosshair_bottom).setBackgroundColor(color)
        root.findViewById<View>(R.id.crosshair_left).setBackgroundColor(color)
        root.findViewById<View>(R.id.crosshair_right).setBackgroundColor(color)
    }

    @Suppress("DEPRECATION")
    private fun setWakeLockActive(active: Boolean) {
        if (active) {
            if (wakeLock == null) {
                val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
                wakeLock = powerManager.newWakeLock(
                    PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ON_AFTER_RELEASE,
                    "skgaming:wake_lock"
                )
            }
            wakeLock?.acquire(3600 * 1000L /* 1 hour */)
            Toast.makeText(this, "Screen Keep-Awake ON (No timeout during game)", Toast.LENGTH_SHORT).show()
        } else {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
            wakeLock = null
            Toast.makeText(this, "Screen Keep-Awake OFF", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startZoneTimer(tv: TextView, btn: Button) {
        zoneTimer?.cancel()
        timerSecondsLeft = 120
        isTimerRunning = true
        btn.text = "Reset"
        btn.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#FF2A55"))
        btn.setTextColor(Color.WHITE)

        zoneTimer = object : CountDownTimer(120000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                val sec = (millisUntilFinished / 1000).toInt()
                timerSecondsLeft = sec
                val minutes = sec / 60
                val seconds = sec % 60
                tv.text = String.format("Safe Zone: %02d:%02d", minutes, seconds)

                // Warning vibrations
                if (sec == 30) {
                    vibrateDevice(200)
                } else if (sec == 10 || sec == 5) {
                    vibrateDevice(100)
                }
            }

            override fun onFinish() {
                isTimerRunning = false
                tv.text = "Zone Collapsed!"
                btn.text = "Start"
                btn.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#00FF66"))
                btn.setTextColor(Color.BLACK)
                vibrateDevice(500)
            }
        }.start()
    }

    private fun stopZoneTimer(tv: TextView, btn: Button) {
        zoneTimer?.cancel()
        isTimerRunning = false
        tv.text = "Safe Zone: 02:00"
        btn.text = "Start"
        btn.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#00FF66"))
        btn.setTextColor(Color.BLACK)
    }

    private fun vibrateDevice(durationMillis: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(durationMillis, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                @Suppress("DEPRECATION")
                vibrator?.vibrate(durationMillis)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _isRunning.value = false
        _isCrosshairActive.value = false

        unhideRunnable?.let { handler.removeCallbacks(it) }
        zoneTimer?.cancel()

        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
        }
        wakeLock = null

        try {
            bubbleView?.let { windowManager.removeView(it) }
            toolboxView?.let { windowManager.removeView(it) }
            crosshairView?.let { windowManager.removeView(it) }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        bubbleView = null
        toolboxView = null
        crosshairView = null
    }
}
