package com.example.engine

import android.content.Context
import android.net.Uri
import com.example.data.model.*
import com.example.data.remote.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.concurrent.TimeUnit

object RemoteEnhancerClient {

    private fun buildRetrofit(baseUrl: String): Retrofit {
        val cleanUrl = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"

        val client = OkHttpClient.Builder()
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .writeTimeout(120, TimeUnit.SECONDS)
            .addInterceptor(HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BASIC
            })
            .build()

        val moshi = Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()

        return Retrofit.Builder()
            .baseUrl(cleanUrl)
            .client(client)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
    }

    suspend fun testServerHealth(serverUrl: String): Result<HealthCheckResponse> {
        return try {
            val api = buildRetrofit(serverUrl).create(EnhancementApiService::class.java)
            val health = api.checkHealth()
            Result.success(health)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun processVideoRemote(
        context: Context,
        serverUrl: String,
        inputUri: Uri,
        metadata: VideoMetadata,
        options: EnhancementOptions
    ): Flow<ProcessingProgress> = flow {
        emit(
            ProcessingProgress(
                stage = ProcessingStage.VERIFYING_MODEL,
                percentage = 5,
                statusMessage = "Connecting to GPU Backend ($serverUrl) and checking Real-ESRGAN model..."
            )
        )

        val api = try {
            buildRetrofit(serverUrl).create(EnhancementApiService::class.java)
        } catch (e: Exception) {
            emit(
                ProcessingProgress(
                    stage = ProcessingStage.FAILED,
                    statusMessage = "AI ENHANCEMENT UNAVAILABLE: Invalid backend URL.",
                    error = e.localizedMessage
                )
            )
            return@flow
        }

        // Check health
        val health = try {
            api.checkHealth()
        } catch (e: Exception) {
            emit(
                ProcessingProgress(
                    stage = ProcessingStage.FAILED,
                    statusMessage = "AI ENHANCEMENT UNAVAILABLE: Server offline or unreachable at $serverUrl.",
                    error = e.localizedMessage ?: "Connection refused"
                )
            )
            return@flow
        }

        if (!health.modelLoaded) {
            emit(
                ProcessingProgress(
                    stage = ProcessingStage.FAILED,
                    statusMessage = "AI ENHANCEMENT UNAVAILABLE: Real-ESRGAN model weights not loaded on server.",
                    error = "Model not initialized"
                )
            )
            return@flow
        }

        emit(
            ProcessingProgress(
                stage = ProcessingStage.EXTRACTING_FRAMES,
                percentage = 15,
                statusMessage = "Uploading video to GPU server (${health.device}, ${health.modelName})..."
            )
        )

        // Copy uri to temp file for multipart upload
        val tempFile = File(context.cacheDir, "upload_${System.currentTimeMillis()}.mp4")
        try {
            context.contentResolver.openInputStream(inputUri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            }
        } catch (e: Exception) {
            emit(
                ProcessingProgress(
                    stage = ProcessingStage.FAILED,
                    statusMessage = "Failed to prepare video file for upload.",
                    error = e.localizedMessage
                )
            )
            return@flow
        }

        val requestFile = tempFile.asRequestBody("video/*".toMediaTypeOrNull())
        val videoPart = MultipartBody.Part.createFormData("video", metadata.fileName, requestFile)

        val modeBody = options.mode.id.toRequestBody("text/plain".toMediaTypeOrNull())
        val upscaleBody = options.upscaleFactor.factor.toString().toRequestBody("text/plain".toMediaTypeOrNull())
        val resBody = options.targetResolution.name.toRequestBody("text/plain".toMediaTypeOrNull())
        val denoiseBody = options.denoise.toString().toRequestBody("text/plain".toMediaTypeOrNull())
        val deblurBody = options.deblur.toString().toRequestBody("text/plain".toMediaTypeOrNull())
        val watermarkBody = options.watermarkText.toRequestBody("text/plain".toMediaTypeOrNull())

        val jobResponse = try {
            api.startEnhance(
                video = videoPart,
                mode = modeBody,
                upscaleFactor = upscaleBody,
                targetResolution = resBody,
                denoise = denoiseBody,
                deblur = deblurBody,
                watermark = watermarkBody
            )
        } catch (e: Exception) {
            tempFile.delete()
            emit(
                ProcessingProgress(
                    stage = ProcessingStage.FAILED,
                    statusMessage = "Server rejected enhancement job: ${e.message}",
                    error = e.localizedMessage
                )
            )
            return@flow
        }

        tempFile.delete()
        val jobId = jobResponse.jobId

        emit(
            ProcessingProgress(
                stage = ProcessingStage.AI_ENHANCING_FRAMES,
                percentage = 20,
                statusMessage = "Job queued on GPU worker: $jobId"
            )
        )

        // Poll job status
        var isDone = false
        var attempts = 0
        val maxAttempts = 300 // up to 5 minutes

        while (!isDone && attempts < maxAttempts) {
            delay(1000)
            attempts++

            val status = try {
                api.getJobStatus(jobId)
            } catch (e: Exception) {
                // Transient network jitter, retry next loop
                continue
            }

            when (status.status) {
                "PROCESSING" -> {
                    val p = status.progress
                    val currentFrame = p?.currentFrame ?: 0
                    val totalFrames = p?.totalFrames ?: 0
                    val percent = p?.percentage ?: 25
                    val fps = p?.fps ?: 0f
                    val msg = p?.message ?: "AI Super-Resolution Processing ($currentFrame/$totalFrames frames)"

                    emit(
                        ProcessingProgress(
                            stage = ProcessingStage.AI_ENHANCING_FRAMES,
                            currentFrame = currentFrame,
                            totalFrames = totalFrames,
                            percentage = percent.coerceIn(20, 90),
                            fps = fps,
                            statusMessage = msg
                        )
                    )
                }
                "COMPLETED" -> {
                    isDone = true
                    emit(
                        ProcessingProgress(
                            stage = ProcessingStage.VERIFYING_OUTPUT,
                            percentage = 94,
                            statusMessage = "Downloading and verifying completed AI video..."
                        )
                    )

                    // Download enhanced video
                    val outputFile = File(context.filesDir, "SK_ENHANCED_${UUID.randomUUID().toString().take(8)}.mp4")
                    try {
                        val response = api.downloadEnhancedVideo(jobId)
                        val body = response.body()
                        if (body != null) {
                            FileOutputStream(outputFile).use { out ->
                                body.byteStream().copyTo(out)
                            }
                        } else {
                            throw Exception("Empty download response body")
                        }
                    } catch (e: Exception) {
                        emit(
                            ProcessingProgress(
                                stage = ProcessingStage.FAILED,
                                statusMessage = "Failed to download enhanced video from backend.",
                                error = e.localizedMessage
                            )
                        )
                        return@flow
                    }

                    emit(
                        ProcessingProgress(
                            stage = ProcessingStage.COMPLETED,
                            currentFrame = status.framesProcessed ?: 100,
                            totalFrames = status.framesProcessed ?: 100,
                            percentage = 100,
                            statusMessage = "Video Successfully Enhanced with Real-ESRGAN AI and SK MUZAMMEL 10K Watermark!"
                        )
                    )
                }
                "FAILED" -> {
                    isDone = true
                    emit(
                        ProcessingProgress(
                            stage = ProcessingStage.FAILED,
                            statusMessage = "AI ENHANCEMENT UNAVAILABLE: ${status.error ?: "Backend model failure"}",
                            error = status.error
                        )
                    )
                    return@flow
                }
            }
        }

        if (!isDone) {
            emit(
                ProcessingProgress(
                    stage = ProcessingStage.FAILED,
                    statusMessage = "Backend processing timed out. Please try a shorter video or check GPU server load.",
                    error = "Timeout"
                )
            )
        }
    }.flowOn(Dispatchers.IO)
}
