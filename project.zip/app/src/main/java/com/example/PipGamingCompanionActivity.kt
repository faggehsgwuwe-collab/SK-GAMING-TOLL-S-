package com.example

import android.app.PictureInPictureParams
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme

class PipGamingCompanionActivity : ComponentActivity() {

    private var isPipMode by mutableStateOf(false)
    private var timerSeconds by mutableIntStateOf(120)
    private var isTimerRunning by mutableStateOf(false)
    private var countDownTimer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                if (isPipMode) {
                    PipMiniHud(
                        seconds = timerSeconds,
                        isRunning = isTimerRunning,
                        onToggleTimer = { toggleTimer() }
                    )
                } else {
                    PipFullView(
                        seconds = timerSeconds,
                        isRunning = isTimerRunning,
                        onToggleTimer = { toggleTimer() },
                        onEnterPip = { enterPip() },
                        onBack = { finish() }
                    )
                }
            }
        }
    }

    private fun toggleTimer() {
        if (isTimerRunning) {
            countDownTimer?.cancel()
            isTimerRunning = false
            timerSeconds = 120
        } else {
            isTimerRunning = true
            countDownTimer = object : CountDownTimer((timerSeconds * 1000).toLong(), 1000) {
                override fun onTick(millisUntilFinished: Long) {
                    timerSeconds = (millisUntilFinished / 1000).toInt()
                }

                override fun onFinish() {
                    isTimerRunning = false
                    timerSeconds = 0
                }
            }.start()
        }
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val aspectRatio = Rational(16, 9)
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(aspectRatio)
                .build()
            enterPictureInPictureMode(params)
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        enterPip()
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isPipMode = isInPictureInPictureMode
    }

    override fun onDestroy() {
        super.onDestroy()
        countDownTimer?.cancel()
    }
}

@Composable
fun PipMiniHud(
    seconds: Int,
    isRunning: Boolean,
    onToggleTimer: () -> Unit
) {
    val mins = seconds / 60
    val secs = seconds % 60
    val formattedTime = String.format("%02d:%02d", mins, secs)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0E14))
            .border(2.dp, Color(0xFF00FF66), RoundedCornerShape(8.dp))
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (isRunning) Color(0xFF00FF66) else Color(0xFFFF2A55))
                )
                Text(
                    text = "SK TACTICAL PiP",
                    color = Color(0xFF00FF66),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "ZONE: $formattedTime",
                color = if (seconds <= 30) Color(0xFFFF2A55) else Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Black
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "Woodpecker: 240 Head | MP40: 132 Head",
                color = Color(0xFF00E5FF),
                fontSize = 9.sp
            )
        }
    }
}

@Composable
fun PipFullView(
    seconds: Int,
    isRunning: Boolean,
    onToggleTimer: () -> Unit,
    onEnterPip: () -> Unit,
    onBack: () -> Unit
) {
    val mins = seconds / 60
    val secs = seconds % 60
    val formattedTime = String.format("%02d:%02d", mins, secs)

    Scaffold(
        containerColor = Color(0xFF0A0E14)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("pip_back_button")) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color(0xFF00FF66)
                    )
                }
                Text(
                    text = "SK TACTICAL COMPANION",
                    color = Color(0xFF00FF66),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // PiP Launcher Banner
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131B24)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, Color(0xFF00FF66), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "📱 Native Picture-in-Picture (PiP)",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Float this tactical companion screen on top of Free Fire or any other app. Tracks safe zone collapse times and gun headshot stats in real-time.",
                        color = Color(0xFF8B949E),
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = onEnterPip,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF00FF66),
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("enter_pip_button")
                    ) {
                        Text(
                            text = "FLOAT AS PiP WINDOW NOW",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Live Match Timer Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131B24)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "FREE FIRE SAFE ZONE SHRINK TIMER",
                        color = Color(0xFF8B949E),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = formattedTime,
                        color = if (seconds <= 30) Color(0xFFFF2A55) else Color(0xFF00FF66),
                        fontSize = 42.sp,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onToggleTimer,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isRunning) Color(0xFFFF2A55) else Color(0xFF00E5FF),
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(
                            imageVector = if (isRunning) Icons.Default.Refresh else Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isRunning) "Reset Timer" else "Start 2-Min Zone Countdown",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Weapon Stats Quick Matrix
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131B24)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "🎯 Pro Weapons Headshot Damage Matrix",
                        color = Color(0xFF00FF66),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    WeaponRow("Woodpecker", "240+ Head", "60 Body", "Long Range")
                    WeaponRow("M1887", "180+ Head (x2)", "95 Body", "Close Combat")
                    WeaponRow("MP40", "132 Head", "24 Body", "Rush SMG")
                    WeaponRow("AWM / M82B", "300+ Head", "150 Body", "Sniper Penetration")
                    WeaponRow("Groza", "165 Head", "36 Body", "Air Drop AR")
                }
            }
        }
    }
}

@Composable
private fun WeaponRow(name: String, headshot: String, body: String, role: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .background(Color(0xFF182330), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(text = name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(text = role, color = Color(0xFF8B949E), fontSize = 10.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(text = headshot, color = Color(0xFFFF2A55), fontSize = 13.sp, fontWeight = FontWeight.Black)
            Text(text = body, color = Color(0xFF00E5FF), fontSize = 10.sp)
        }
    }
}
