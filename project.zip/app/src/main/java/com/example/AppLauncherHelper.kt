package com.example

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast

object AppLauncherHelper {

    const val PKG_FREE_FIRE = "com.dts.freefireth"
    const val PKG_FREE_FIRE_MAX = "com.dts.freefiremax"
    const val PKG_WHATSAPP = "com.whatsapp"
    const val PKG_WHATSAPP_BUS = "com.whatsapp.w4b"
    const val PKG_YOUTUBE = "com.google.android.youtube"
    const val PKG_MESSENGER = "com.facebook.orca"
    const val PKG_CHROME = "com.android.chrome"
    const val PKG_DISCORD = "com.discord"

    fun isAppInstalled(context: Context, packageName: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun launchAppOrFallback(
        context: Context,
        packageName: String,
        fallbackUrl: String? = null,
        displayName: String = packageName
    ) {
        val pm = context.packageManager

        // Special handling for Free Fire / Free Fire Max
        val targetPackage = if (packageName == PKG_FREE_FIRE) {
            when {
                isAppInstalled(context, PKG_FREE_FIRE_MAX) -> PKG_FREE_FIRE_MAX
                isAppInstalled(context, PKG_FREE_FIRE) -> PKG_FREE_FIRE
                else -> PKG_FREE_FIRE
            }
        } else if (packageName == PKG_WHATSAPP) {
            when {
                isAppInstalled(context, PKG_WHATSAPP) -> PKG_WHATSAPP
                isAppInstalled(context, PKG_WHATSAPP_BUS) -> PKG_WHATSAPP_BUS
                else -> PKG_WHATSAPP
            }
        } else {
            packageName
        }

        val launchIntent = pm.getLaunchIntentForPackage(targetPackage)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                context.startActivity(launchIntent)
            } catch (e: Exception) {
                Toast.makeText(context, "Could not launch $displayName: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        } else if (fallbackUrl != null) {
            try {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(browserIntent)
                Toast.makeText(context, "Opening $displayName in browser...", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                openPlayStore(context, targetPackage, displayName)
            }
        } else {
            openPlayStore(context, targetPackage, displayName)
        }
    }

    fun openPlayStore(context: Context, packageName: String, displayName: String) {
        try {
            val storeIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(storeIntent)
        } catch (e: Exception) {
            try {
                val webStoreIntent = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=$packageName")
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(webStoreIntent)
            } catch (ex: Exception) {
                Toast.makeText(context, "$displayName is not installed", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
