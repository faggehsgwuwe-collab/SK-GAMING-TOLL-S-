package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.ViewColumn
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

enum class ComparisonDisplayMode {
    SPLIT_SLIDER,
    SIDE_BY_SIDE,
    FULL_ENHANCED
}

@Composable
fun BeforeAfterSlider(
    originalBitmap: Bitmap?,
    enhancedBitmap: Bitmap?,
    originalResolution: String,
    enhancedResolution: String,
    modifier: Modifier = Modifier
) {
    var displayMode by remember { mutableStateOf(ComparisonDisplayMode.SPLIT_SLIDER) }
    var splitFraction by remember { mutableFloatStateOf(0.5f) }
    var containerWidthPx by remember { mutableFloatStateOf(1f) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(SurfaceNavy)
            .border(1.dp, SurfaceGlassBorder, RoundedCornerShape(20.dp))
            .padding(14.dp)
    ) {
        // Mode Selector Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Interactive Comparison",
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                IconButton(
                    onClick = { displayMode = ComparisonDisplayMode.SPLIT_SLIDER },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (displayMode == ComparisonDisplayMode.SPLIT_SLIDER) ElectricBlue.copy(0.25f) else Color.Transparent)
                ) {
                    Icon(
                        imageVector = Icons.Default.CompareArrows,
                        contentDescription = "Split Slider",
                        tint = if (displayMode == ComparisonDisplayMode.SPLIT_SLIDER) ElectricBlue else TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                IconButton(
                    onClick = { displayMode = ComparisonDisplayMode.SIDE_BY_SIDE },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (displayMode == ComparisonDisplayMode.SIDE_BY_SIDE) ElectricBlue.copy(0.25f) else Color.Transparent)
                ) {
                    Icon(
                        imageVector = Icons.Default.ViewColumn,
                        contentDescription = "Side by Side",
                        tint = if (displayMode == ComparisonDisplayMode.SIDE_BY_SIDE) ElectricBlue else TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                IconButton(
                    onClick = { displayMode = ComparisonDisplayMode.FULL_ENHANCED },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (displayMode == ComparisonDisplayMode.FULL_ENHANCED) ElectricBlue.copy(0.25f) else Color.Transparent)
                ) {
                    Icon(
                        imageVector = Icons.Default.Visibility,
                        contentDescription = "Full Enhanced",
                        tint = if (displayMode == ComparisonDisplayMode.FULL_ENHANCED) ElectricBlue else TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Main Comparison View Area
        when (displayMode) {
            ComparisonDisplayMode.SPLIT_SLIDER -> {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(240.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.Black)
                        .onSizeChanged { containerWidthPx = it.width.toFloat() }
                        .pointerInput(Unit) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                if (containerWidthPx > 0) {
                                    val newFraction = splitFraction + (dragAmount.x / containerWidthPx)
                                    splitFraction = newFraction.coerceIn(0.05f, 0.95f)
                                }
                            }
                        }
                        .pointerInput(Unit) {
                            detectTapGestures { offset ->
                                if (containerWidthPx > 0) {
                                    splitFraction = (offset.x / containerWidthPx).coerceIn(0.05f, 0.95f)
                                }
                            }
                        }
                ) {
                    // Enhanced Image (Full base)
                    if (enhancedBitmap != null) {
                        Image(
                            bitmap = enhancedBitmap.asImageBitmap(),
                            contentDescription = "Enhanced Frame",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }

                    // Original Image (Clipped to splitFraction)
                    if (originalBitmap != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(SplitFractionShape(splitFraction))
                        ) {
                            Image(
                                bitmap = originalBitmap.asImageBitmap(),
                                contentDescription = "Original Frame",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }
                    }

                    // Divider Line
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .width(2.dp)
                            .align(Alignment.CenterStart)
                            .offset(x = (containerWidthPx * splitFraction).dp / 2.75f)
                            .background(Color.White)
                    )

                    // Floating Slider Handle
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .align(Alignment.CenterStart)
                            .offset(x = (containerWidthPx * splitFraction).dp / 2.75f - 19.dp)
                            .clip(CircleShape)
                            .background(CyberBlack)
                            .border(2.dp, ElectricBlue, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CompareArrows,
                            contentDescription = "Drag to compare",
                            tint = ElectricBlue,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Badges
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp)
                            .align(Alignment.TopStart),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StatusBadge(
                            text = "ORIGINAL • $originalResolution",
                            color = Color(0xFFCBD5E1)
                        )
                        StatusBadge(
                            text = "AI ENHANCED • $enhancedResolution",
                            color = ElectricBlue
                        )
                    }

                    // Watermark indicator on enhanced side
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color.Black.copy(0.4f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "SK MUZAMMEL 10K",
                            color = Color.White.copy(0.5f),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "◀ Drag handle horizontally to inspect pixel detail difference ▶",
                    color = TextMuted,
                    fontSize = 11.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }

            ComparisonDisplayMode.SIDE_BY_SIDE -> {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Original pane
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black)
                    ) {
                        if (originalBitmap != null) {
                            Image(
                                bitmap = originalBitmap.asImageBitmap(),
                                contentDescription = "Original Frame",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }
                        StatusBadge(
                            text = "ORIGINAL\n$originalResolution",
                            color = Color(0xFFCBD5E1),
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(6.dp)
                        )
                    }

                    // Enhanced pane
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black)
                            .border(1.dp, ElectricBlue.copy(0.4f), RoundedCornerShape(12.dp))
                    ) {
                        if (enhancedBitmap != null) {
                            Image(
                                bitmap = enhancedBitmap.asImageBitmap(),
                                contentDescription = "Enhanced Frame",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }
                        StatusBadge(
                            text = "AI 4K/FHD\n$enhancedResolution",
                            color = ElectricBlue,
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(6.dp)
                        )
                        Text(
                            text = "SK MUZAMMEL 10K",
                            color = Color.White.copy(0.45f),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(6.dp)
                        )
                    }
                }
            }

            ComparisonDisplayMode.FULL_ENHANCED -> {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(240.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.Black)
                ) {
                    if (enhancedBitmap != null) {
                        Image(
                            bitmap = enhancedBitmap.asImageBitmap(),
                            contentDescription = "Full Enhanced Frame",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                    StatusBadge(
                        text = "VERIFIED AI OUTPUT • $enhancedResolution",
                        color = SuccessGreen,
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(10.dp)
                    )
                    Text(
                        text = "SK MUZAMMEL 10K",
                        color = Color.White.copy(0.5f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(10.dp)
                    )
                }
            }
        }
    }
}

class SplitFractionShape(private val fraction: Float) : Shape {
    override fun createOutline(
        size: Size,
        layoutDirection: LayoutDirection,
        density: Density
    ): Outline {
        val splitX = size.width * fraction
        val rect = Rect(0f, 0f, splitX, size.height)
        return Outline.Rectangle(rect)
    }
}
