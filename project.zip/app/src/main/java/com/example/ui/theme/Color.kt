package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Background and Surface
val CyberBlack = Color(0xFF07090E)
val ObsidianDark = Color(0xFF0B0E17)
val SurfaceNavy = Color(0xFF10192C)
val SurfaceCard = Color(0xFF152037)
val SurfaceCardElevated = Color(0xFF1B2B48)
val SurfaceGlass = Color(0xCC131F38)
val SurfaceGlassBorder = Color(0x3300D2FF)

// Accents
val ElectricBlue = Color(0xFF00D2FF)
val DeepElectricBlue = Color(0xFF0284C7)
val NeonCyan = Color(0xFF38BDF8)
val VibrantPurple = Color(0xFFA855F7)
val DeepViolet = Color(0xFF7C3AED)
val GlowNeonPink = Color(0xFFEC4899)

// Semantic
val SuccessGreen = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)

// Text
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Gradients
val CyberpunkGradient = Brush.horizontalGradient(
    colors = listOf(ElectricBlue, VibrantPurple)
)

val CardGlowGradient = Brush.linearGradient(
    colors = listOf(
        Color(0x3300D2FF),
        Color(0x1A8B5CF6),
        Color(0x05000000)
    )
)

val BackgroundHeroGradient = Brush.verticalGradient(
    colors = listOf(
        Color(0xFF0B1224),
        Color(0xFF07090E)
    )
)
