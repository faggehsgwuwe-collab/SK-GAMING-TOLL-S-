package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NeonGreen = Color(0xFF00FF66)
val NeonGreenLight = Color(0xFF5CFF95)
val NeonGreenDark = Color(0xFF008033)
val NeonGreenContainer = Color(0xFF003B17)

val CyberCyan = Color(0xFF00E5FF)
val NeonRed = Color(0xFFFF2A55)
val NeonAmber = Color(0xFFFFB300)

val DarkBackground = Color(0xFF0A0E14)
val DarkSurface = Color(0xFF121820)
val DarkSurfaceCard = Color(0xFF161F2E)
val DarkSurfaceElevated = Color(0xFF1A2638)

val TextWhite = Color(0xFFF0F6FC)
val TextSecondary = Color(0xFF8B949E)
val TextMuted = Color(0xFF484F58)
val BorderCyber = Color(0xFF23382E)
