package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.EngineMode
import com.example.data.model.TargetResolution
import com.example.ui.MainViewModel
import com.example.ui.components.GlassCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.util.StringsManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val language by viewModel.language.collectAsState()
    val engineMode by viewModel.engineMode.collectAsState()
    val backendUrl by viewModel.backendUrl.collectAsState()
    val backendStatus by viewModel.backendStatus.collectAsState()
    val options by viewModel.enhancementOptions.collectAsState()

    var urlInput by remember(backendUrl) { mutableStateOf(backendUrl) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = StringsManager.get("settings_title", language),
            color = TextPrimary,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        // Language Section
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Language, contentDescription = null, tint = ElectricBlue)
                Text(
                    text = StringsManager.get("language_section", language),
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FilterChip(
                    selected = language == AppLanguage.ENGLISH,
                    onClick = { viewModel.setLanguage(AppLanguage.ENGLISH) },
                    label = { Text("English (US)") },
                    modifier = Modifier.weight(1f),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ElectricBlue.copy(0.25f),
                        selectedLabelColor = ElectricBlue
                    )
                )

                FilterChip(
                    selected = language == AppLanguage.BENGALI,
                    onClick = { viewModel.setLanguage(AppLanguage.BENGALI) },
                    label = { Text("বাংলা (Bengali)") },
                    modifier = Modifier.weight(1f),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = VibrantPurple.copy(0.25f),
                        selectedLabelColor = VibrantPurple
                    )
                )
            }
        }

        // Processing Engine Selection
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Memory, contentDescription = null, tint = ElectricBlue)
                Text(
                    text = StringsManager.get("engine_section", language),
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Embedded Local Engine Option
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (engineMode == EngineMode.LOCAL_EMBEDDED) ElectricBlue.copy(0.12f) else SurfaceNavy)
                    .border(
                        1.dp,
                        if (engineMode == EngineMode.LOCAL_EMBEDDED) ElectricBlue else SurfaceGlassBorder,
                        RoundedCornerShape(12.dp)
                    )
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = engineMode == EngineMode.LOCAL_EMBEDDED,
                    onClick = { viewModel.setEngineMode(EngineMode.LOCAL_EMBEDDED) },
                    colors = RadioButtonDefaults.colors(selectedColor = ElectricBlue)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = StringsManager.get("engine_local", language),
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Real frame processing & detail synthesis on phone",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Remote GPU Server Option
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (engineMode == EngineMode.REMOTE_FASTAPI) VibrantPurple.copy(0.12f) else SurfaceNavy)
                    .border(
                        1.dp,
                        if (engineMode == EngineMode.REMOTE_FASTAPI) VibrantPurple else SurfaceGlassBorder,
                        RoundedCornerShape(12.dp)
                    )
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = engineMode == EngineMode.REMOTE_FASTAPI,
                    onClick = { viewModel.setEngineMode(EngineMode.REMOTE_FASTAPI) },
                    colors = RadioButtonDefaults.colors(selectedColor = VibrantPurple)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = StringsManager.get("engine_remote", language),
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "PyTorch Real-ESRGAN GPU acceleration (FastAPI)",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }

            if (engineMode == EngineMode.REMOTE_FASTAPI) {
                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = urlInput,
                    onValueChange = {
                        urlInput = it
                        viewModel.setBackendUrl(it)
                    },
                    label = { Text(StringsManager.get("server_url_label", language)) },
                    placeholder = { Text(StringsManager.get("server_url_hint", language)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("backend_url_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = SurfaceGlassBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedLabelColor = ElectricBlue,
                        unfocusedLabelColor = TextSecondary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = { viewModel.testBackend() },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue.copy(0.2f))
                ) {
                    Icon(Icons.Default.Speed, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(StringsManager.get("test_connection", language), color = ElectricBlue)
                }

                if (backendStatus != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = backendStatus!!,
                        color = if (backendStatus!!.contains("Connected")) SuccessGreen else WarningAmber,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Watermark Policy Card
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.BrandingWatermark, contentDescription = null, tint = VibrantPurple)
                Text(
                    text = StringsManager.get("watermark_preview_title", language),
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = StringsManager.get("watermark_preview_desc", language),
                color = TextSecondary,
                fontSize = 12.sp,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.Black)
                    .border(1.dp, SurfaceGlassBorder, RoundedCornerShape(10.dp))
                    .padding(12.dp),
                contentAlignment = Alignment.BottomEnd
            ) {
                Text(
                    text = "SK MUZAMMEL 10K",
                    color = Color.White.copy(0.28f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }
        }

        // App & Developer Info
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Info, contentDescription = null, tint = ElectricBlue)
                Text(
                    text = StringsManager.get("about_section", language),
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "SK VIDEO ENHANCER",
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = StringsManager.get("app_version", language),
                color = TextSecondary,
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Lead Developer & Branding: SK MUZAMMEL 10K",
                color = VibrantPurple,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "Genuine AI Super-Resolution Engine with Real-ESRGAN Architecture",
                color = TextMuted,
                fontSize = 11.sp
            )
        }

        Spacer(modifier = Modifier.height(70.dp))
    }
}
