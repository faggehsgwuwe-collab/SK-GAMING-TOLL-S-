package com.example.ui.screens

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.*
import com.example.ui.MainViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.StringsManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val language by viewModel.language.collectAsState()
    val selectedUri by viewModel.selectedVideoUri.collectAsState()
    val metadata by viewModel.videoMetadata.collectAsState()
    val thumbnail by viewModel.videoThumbnail.collectAsState()
    val options by viewModel.enhancementOptions.collectAsState()
    val progress by viewModel.processingProgress.collectAsState()
    val result by viewModel.enhancedResult.collectAsState()
    val origFrame by viewModel.originalFrameBitmap.collectAsState()
    val enhFrame by viewModel.enhancedFrameBitmap.collectAsState()

    // Android Photo Picker
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.selectVideo(uri)
        }
    }

    // Fallback file picker for all video MIME types
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.selectVideo(uri)
        }
    }

    fun openPicker() {
        try {
            videoPickerLauncher.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
            )
        } catch (_: Exception) {
            filePickerLauncher.launch("video/*")
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .clip(RoundedCornerShape(22.dp))
                .border(1.dp, SurfaceGlassBorder, RoundedCornerShape(22.dp))
        ) {
            Image(
                painter = painterResource(id = R.drawable.hero_enhancer_banner_1793536981658),
                contentDescription = "AI Control Center Banner",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            // Dark gradient overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        androidx.compose.ui.graphics.Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                CyberBlack.copy(alpha = 0.85f),
                                CyberBlack
                            )
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.Bottom
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatusBadge(
                        text = "REAL-ESRGAN NEURAL ENGINE",
                        color = ElectricBlue
                    )
                    StatusBadge(
                        text = "SK MUZAMMEL 10K",
                        color = VibrantPurple
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = StringsManager.get("app_title", language),
                    color = TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.8.sp
                )

                Text(
                    text = StringsManager.get("tagline", language),
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        // Processing HUD State (Active)
        AnimatedVisibility(
            visible = progress != null && progress?.stage != ProcessingStage.COMPLETED,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            progress?.let { p ->
                ProcessingHud(
                    progress = p,
                    onCancel = { viewModel.cancelEnhancement() }
                )
            }
        }

        // Completed Result State
        AnimatedVisibility(
            visible = result != null,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            result?.let { res ->
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    // Success Banner
                    GlassCard(
                        borderColor = SuccessGreen.copy(0.5f),
                        backgroundColor = Color(0x2210B981)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = "Verified",
                                tint = SuccessGreen,
                                modifier = Modifier.size(28.dp)
                            )
                            Column {
                                Text(
                                    text = StringsManager.get("complete_title", language),
                                    color = TextPrimary,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = StringsManager.get("complete_verified", language),
                                    color = SuccessGreen,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    // Interactive Before & After Slider
                    BeforeAfterSlider(
                        originalBitmap = origFrame,
                        enhancedBitmap = enhFrame,
                        originalResolution = "${res.originalWidth}x${res.originalHeight}",
                        enhancedResolution = "${res.enhancedWidth}x${res.enhancedHeight}"
                    )

                    // Diagnostics Comparison Card
                    GlassCard {
                        Text(
                            text = "Verification & Quality Telemetry",
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Original Source", color = TextMuted, fontSize = 11.sp)
                                Text("${res.originalWidth}x${res.originalHeight}", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text(String.format("%.1f MB", res.originalSizeBytes / (1024.0 * 1024.0)), color = TextSecondary, fontSize = 12.sp)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.ArrowForward, contentDescription = null, tint = ElectricBlue)
                                Text("${res.options.upscaleFactor.label}", color = NeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Enhanced AI Output", color = TextMuted, fontSize = 11.sp)
                                Text("${res.enhancedWidth}x${res.enhancedHeight}", color = ElectricBlue, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(String.format("%.1f MB", res.enhancedSizeBytes / (1024.0 * 1024.0)), color = TextSecondary, fontSize = 12.sp)
                            }
                        }

                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 10.dp),
                            color = SurfaceGlassBorder
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Watermark Embedded", color = TextSecondary, fontSize = 12.sp)
                            Text("SK MUZAMMEL 10K", color = VibrantPurple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Processed Frames", color = TextSecondary, fontSize = 12.sp)
                            Text("${res.framesProcessed} Frames", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    // Action Buttons
                    GlowingButton(
                        text = StringsManager.get("download_button", language),
                        onClick = { viewModel.downloadEnhancedVideo() },
                        modifier = Modifier.fillMaxWidth(),
                        leadingIcon = {
                            Icon(Icons.Default.Download, contentDescription = null, tint = Color.White)
                        },
                        testTag = "download_enhanced_button"
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.shareEnhancedVideo() },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, SurfaceGlassBorder)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(StringsManager.get("share_button", language), color = TextPrimary, fontSize = 13.sp)
                        }

                        OutlinedButton(
                            onClick = { viewModel.resetToUpload() },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, SurfaceGlassBorder)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(StringsManager.get("new_video_button", language), color = ElectricBlue, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        // Upload Area / Video Config State (when no active result)
        if (result == null && (progress == null || progress?.stage == ProcessingStage.FAILED)) {
            if (metadata == null) {
                // Drag / Select Area
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { openPicker() }
                        .testTag("upload_dropzone"),
                    borderColor = ElectricBlue.copy(0.35f),
                    backgroundColor = SurfaceNavy.copy(0.7f)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(ElectricBlue.copy(0.12f))
                                .border(1.5.dp, ElectricBlue.copy(0.5f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudUpload,
                                contentDescription = "Upload",
                                tint = ElectricBlue,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = StringsManager.get("upload_hero_title", language),
                            color = TextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = StringsManager.get("upload_hero_desc", language),
                            color = TextSecondary,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 16.dp),
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatusBadge("MP4", ElectricBlue)
                            StatusBadge("MOV", VibrantPurple)
                            StatusBadge("MKV", NeonCyan)
                            StatusBadge("WEBM", Color(0xFFF59E0B))
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        GlowingButton(
                            text = StringsManager.get("select_video_button", language),
                            onClick = { openPicker() },
                            leadingIcon = {
                                Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = Color.White)
                            },
                            testTag = "select_video_button"
                        )
                    }
                }
            } else {
                // Video is selected: Show Diagnostics + Enhancement Controls
                metadata?.let { meta ->
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = StringsManager.get("video_specs_title", language),
                                color = TextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )

                            TextButton(onClick = { openPicker() }) {
                                Icon(Icons.Default.Edit, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(StringsManager.get("change_video_button", language), color = ElectricBlue, fontSize = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Video Thumbnail + Meta Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(width = 110.dp, height = 75.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.Black)
                            ) {
                                if (thumbnail != null) {
                                    Image(
                                        bitmap = thumbnail!!.asImageBitmap(),
                                        contentDescription = "Video Preview",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .padding(4.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color.Black.copy(0.7f))
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Text(meta.durationFormatted, color = Color.White, fontSize = 10.sp)
                                }
                            }

                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(meta.fileName, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                Text("${StringsManager.get("resolution", language)}: ${meta.resolutionFormatted}", color = TextSecondary, fontSize = 12.sp)
                                Text("${StringsManager.get("file_size", language)}: ${meta.sizeFormatted} • ${String.format("%.1f FPS", meta.frameRate)}", color = TextSecondary, fontSize = 12.sp)
                                Text(
                                    text = if (meta.hasAudio) StringsManager.get("has_audio", language) else StringsManager.get("no_audio", language),
                                    color = if (meta.hasAudio) SuccessGreen else TextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    // Enhancement Controls Card
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = StringsManager.get("enhancement_settings", language),
                            color = TextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // AI Model Level
                        Text(StringsManager.get("mode_title", language), color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = options.mode == EnhancementMode.BASIC,
                                onClick = { viewModel.updateOptions { it.copy(mode = EnhancementMode.BASIC) } },
                                label = { Text(StringsManager.get("mode_basic", language)) },
                                modifier = Modifier.weight(1f),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ElectricBlue.copy(0.2f),
                                    selectedLabelColor = ElectricBlue
                                )
                            )
                            FilterChip(
                                selected = options.mode == EnhancementMode.HIGH_QUALITY,
                                onClick = { viewModel.updateOptions { it.copy(mode = EnhancementMode.HIGH_QUALITY) } },
                                label = { Text(StringsManager.get("mode_hq", language)) },
                                modifier = Modifier.weight(1f),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = VibrantPurple.copy(0.25f),
                                    selectedLabelColor = VibrantPurple
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Super-Resolution Upscale Factor
                        Text(StringsManager.get("upscale_title", language), color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            UpscaleFactor.entries.forEach { factor ->
                                FilterChip(
                                    selected = options.upscaleFactor == factor,
                                    onClick = { viewModel.updateOptions { it.copy(upscaleFactor = factor) } },
                                    label = { Text(factor.label) },
                                    modifier = Modifier.weight(1f),
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = ElectricBlue.copy(0.2f),
                                        selectedLabelColor = ElectricBlue
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Target Resolution
                        Text(StringsManager.get("target_res_title", language), color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TargetResolution.entries.forEach { res ->
                                FilterChip(
                                    selected = options.targetResolution == res,
                                    onClick = { viewModel.updateOptions { it.copy(targetResolution = res) } },
                                    label = { Text(res.label) },
                                    modifier = Modifier.weight(1f),
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = VibrantPurple.copy(0.2f),
                                        selectedLabelColor = VibrantPurple
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Toggles
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(StringsManager.get("toggle_denoise", language), color = TextPrimary, fontSize = 13.sp)
                            Switch(
                                checked = options.denoise,
                                onCheckedChange = { chk -> viewModel.updateOptions { it.copy(denoise = chk) } },
                                colors = SwitchDefaults.colors(checkedThumbColor = ElectricBlue, checkedTrackColor = ElectricBlue.copy(0.4f))
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(StringsManager.get("toggle_deblur", language), color = TextPrimary, fontSize = 13.sp)
                            Switch(
                                checked = options.deblur,
                                onCheckedChange = { chk -> viewModel.updateOptions { it.copy(deblur = chk) } },
                                colors = SwitchDefaults.colors(checkedThumbColor = ElectricBlue, checkedTrackColor = ElectricBlue.copy(0.4f))
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(StringsManager.get("toggle_smooth", language), color = TextPrimary, fontSize = 13.sp)
                            Switch(
                                checked = options.frameInterpolation,
                                onCheckedChange = { chk -> viewModel.updateOptions { it.copy(frameInterpolation = chk) } },
                                colors = SwitchDefaults.colors(checkedThumbColor = VibrantPurple, checkedTrackColor = VibrantPurple.copy(0.4f))
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Watermark Notice Box
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(SurfaceNavy)
                                .border(1.dp, SurfaceGlassBorder, RoundedCornerShape(10.dp))
                                .padding(10.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.BrandingWatermark, contentDescription = null, tint = VibrantPurple, modifier = Modifier.size(18.dp))
                                Text(
                                    text = StringsManager.get("watermark_notice", language),
                                    color = TextSecondary,
                                    fontSize = 11.sp,
                                    lineHeight = 16.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // AI Disclaimer Card
                        Text(
                            text = StringsManager.get("ai_disclaimer", language),
                            color = TextMuted,
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Action Button
                        GlowingButton(
                            text = StringsManager.get("start_enhancement", language),
                            onClick = { viewModel.startEnhancement() },
                            modifier = Modifier.fillMaxWidth(),
                            leadingIcon = {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White)
                            },
                            testTag = "start_ai_enhancement_button"
                        )
                    }
                }
            }
        }
    }
}
