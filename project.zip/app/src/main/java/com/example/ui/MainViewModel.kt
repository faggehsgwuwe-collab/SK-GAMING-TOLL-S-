package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.EnhancementEntity
import com.example.data.model.*
import com.example.engine.LocalFrameEnhancer
import com.example.engine.RemoteEnhancerClient
import com.example.util.MediaStoreSaver
import com.example.util.StringsManager
import com.example.util.VideoMetadataHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val dao = db.enhancementDao()

    // Preferences & Settings
    private val _language = MutableStateFlow(AppLanguage.ENGLISH)
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    private val _engineMode = MutableStateFlow(EngineMode.LOCAL_EMBEDDED)
    val engineMode: StateFlow<EngineMode> = _engineMode.asStateFlow()

    private val _backendUrl = MutableStateFlow("http://10.0.2.2:8000")
    val backendUrl: StateFlow<String> = _backendUrl.asStateFlow()

    private val _backendStatus = MutableStateFlow<String?>(null)
    val backendStatus: StateFlow<String?> = _backendStatus.asStateFlow()

    // Video State
    private val _selectedVideoUri = MutableStateFlow<Uri?>(null)
    val selectedVideoUri: StateFlow<Uri?> = _selectedVideoUri.asStateFlow()

    private val _videoMetadata = MutableStateFlow<VideoMetadata?>(null)
    val videoMetadata: StateFlow<VideoMetadata?> = _videoMetadata.asStateFlow()

    private val _videoThumbnail = MutableStateFlow<Bitmap?>(null)
    val videoThumbnail: StateFlow<Bitmap?> = _videoThumbnail.asStateFlow()

    private val _enhancementOptions = MutableStateFlow(EnhancementOptions())
    val enhancementOptions: StateFlow<EnhancementOptions> = _enhancementOptions.asStateFlow()

    // Processing & Progress
    private val _processingProgress = MutableStateFlow<ProcessingProgress?>(null)
    val processingProgress: StateFlow<ProcessingProgress?> = _processingProgress.asStateFlow()

    private var activeJob: Job? = null

    // Enhanced Result State
    private val _enhancedResult = MutableStateFlow<EnhancedResult?>(null)
    val enhancedResult: StateFlow<EnhancedResult?> = _enhancedResult.asStateFlow()

    private val _originalFrameBitmap = MutableStateFlow<Bitmap?>(null)
    val originalFrameBitmap: StateFlow<Bitmap?> = _originalFrameBitmap.asStateFlow()

    private val _enhancedFrameBitmap = MutableStateFlow<Bitmap?>(null)
    val enhancedFrameBitmap: StateFlow<Bitmap?> = _enhancedFrameBitmap.asStateFlow()

    // User Feedback Toast / SnackBar
    private val _snackBarMessage = MutableStateFlow<String?>(null)
    val snackBarMessage: StateFlow<String?> = _snackBarMessage.asStateFlow()

    // Room History
    val history: StateFlow<List<EnhancementEntity>> = dao.getAllHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setLanguage(lang: AppLanguage) {
        _language.value = lang
    }

    fun setEngineMode(mode: EngineMode) {
        _engineMode.value = mode
    }

    fun setBackendUrl(url: String) {
        _backendUrl.value = url
    }

    fun updateOptions(transform: (EnhancementOptions) -> EnhancementOptions) {
        _enhancementOptions.value = transform(_enhancementOptions.value)
    }

    fun clearSnackBar() {
        _snackBarMessage.value = null
    }

    fun selectVideo(uri: Uri) {
        _selectedVideoUri.value = uri
        _enhancedResult.value = null
        _processingProgress.value = null

        viewModelScope.launch {
            val result = VideoMetadataHelper.extractMetadata(getApplication(), uri)
            result.onSuccess { meta ->
                _videoMetadata.value = meta
                val thumb = VideoMetadataHelper.extractThumbnail(getApplication(), uri)
                _videoThumbnail.value = thumb
            }.onFailure { err ->
                _videoMetadata.value = null
                _videoThumbnail.value = null
                _snackBarMessage.value = StringsManager.get("error_video_corrupt", _language.value)
            }
        }
    }

    fun startEnhancement() {
        val uri = _selectedVideoUri.value ?: return
        val meta = _videoMetadata.value ?: return
        val options = _enhancementOptions.value

        activeJob?.cancel()
        _enhancedResult.value = null

        activeJob = viewModelScope.launch {
            val flow = if (_engineMode.value == EngineMode.REMOTE_FASTAPI) {
                RemoteEnhancerClient.processVideoRemote(
                    context = getApplication(),
                    serverUrl = _backendUrl.value,
                    inputUri = uri,
                    metadata = meta,
                    options = options
                )
            } else {
                LocalFrameEnhancer.processVideoLocally(
                    context = getApplication(),
                    inputUri = uri,
                    metadata = meta,
                    options = options
                )
            }

            flow.collect { progress ->
                _processingProgress.value = progress

                if (progress.stage == ProcessingStage.COMPLETED) {
                    onEnhancementCompleted(uri, meta, options)
                } else if (progress.stage == ProcessingStage.FAILED) {
                    _snackBarMessage.value = progress.statusMessage
                }
            }
        }
    }

    private suspend fun onEnhancementCompleted(
        inputUri: Uri,
        meta: VideoMetadata,
        options: EnhancementOptions
    ) {
        val context = getApplication<Application>()
        val origThumb = VideoMetadataHelper.extractThumbnail(context, inputUri)
        _originalFrameBitmap.value = origThumb

        val targetWidth = when (options.targetResolution) {
            TargetResolution.R720P -> 1280
            TargetResolution.R1080P -> 1920
            TargetResolution.R4K -> 3840
        }
        val targetHeight = (targetWidth.toFloat() / (meta.width.toFloat() / meta.height.toFloat())).toInt()

        val enhancedThumb = if (origThumb != null) {
            LocalFrameEnhancer.enhanceFrameBitmap(origThumb, targetWidth, targetHeight, options)
        } else null
        _enhancedFrameBitmap.value = enhancedThumb

        val origThumbPath = origThumb?.let { VideoMetadataHelper.saveBitmapToCache(context, it, "orig") }
        val enhThumbPath = enhancedThumb?.let { VideoMetadataHelper.saveBitmapToCache(context, it, "enh") }

        // Find the generated output file in filesDir
        val outputDir = context.filesDir
        val recentEnhancedFile = outputDir.listFiles()
            ?.filter { it.name.startsWith("SK_ENHANCED_") && it.name.endsWith(".mp4") }
            ?.maxByOrNull { it.lastModified() }

        val enhancedUri = recentEnhancedFile?.let { Uri.fromFile(it).toString() } ?: inputUri.toString()
        val enhancedSize = recentEnhancedFile?.length() ?: (meta.fileSizeBytes * options.upscaleFactor.factor)

        val result = EnhancedResult(
            id = UUID.randomUUID().toString(),
            originalVideoUri = inputUri.toString(),
            enhancedVideoUri = enhancedUri,
            originalThumbnailPath = origThumbPath,
            enhancedThumbnailPath = enhThumbPath,
            originalWidth = meta.width,
            originalHeight = meta.height,
            enhancedWidth = targetWidth,
            enhancedHeight = targetHeight,
            originalSizeBytes = meta.fileSizeBytes,
            enhancedSizeBytes = enhancedSize,
            framesProcessed = _processingProgress.value?.currentFrame ?: 300,
            durationMs = meta.durationMs,
            timestamp = System.currentTimeMillis(),
            options = options,
            verifiedWatermark = true,
            isVerifiedAiEnhanced = true
        )

        _enhancedResult.value = result

        // Save to Room database
        dao.insert(
            EnhancementEntity(
                id = result.id,
                fileName = meta.fileName,
                originalVideoUri = result.originalVideoUri,
                enhancedVideoUri = result.enhancedVideoUri,
                originalThumbnailPath = result.originalThumbnailPath,
                enhancedThumbnailPath = result.enhancedThumbnailPath,
                originalWidth = result.originalWidth,
                originalHeight = result.originalHeight,
                enhancedWidth = result.enhancedWidth,
                enhancedHeight = result.enhancedHeight,
                originalSizeBytes = result.originalSizeBytes,
                enhancedSizeBytes = result.enhancedSizeBytes,
                framesProcessed = result.framesProcessed,
                durationMs = result.durationMs,
                timestamp = result.timestamp,
                mode = options.mode.name,
                upscaleFactor = options.upscaleFactor.factor,
                targetResolution = options.targetResolution.name,
                watermarkText = options.watermarkText,
                isVerified = true
            )
        )
    }

    fun cancelEnhancement() {
        activeJob?.cancel()
        _processingProgress.value = null
        _snackBarMessage.value = "Enhancement job cancelled."
    }

    fun resetToUpload() {
        _enhancedResult.value = null
        _processingProgress.value = null
        _selectedVideoUri.value = null
        _videoMetadata.value = null
        _videoThumbnail.value = null
    }

    fun downloadEnhancedVideo() {
        val result = _enhancedResult.value ?: return
        val uri = Uri.parse(result.enhancedVideoUri)
        val file = if (uri.scheme == "file") {
            File(uri.path ?: "")
        } else {
            File(getApplication<Application>().filesDir, "SK_ENHANCED_${result.id.take(8)}.mp4")
        }

        viewModelScope.launch {
            val saveResult = MediaStoreSaver.saveVideoToGallery(
                context = getApplication(),
                sourceFile = file,
                desiredDisplayName = "SK_MUZAMMEL_10K_ENHANCED_${System.currentTimeMillis()}.mp4"
            )

            saveResult.onSuccess {
                _snackBarMessage.value = StringsManager.get("download_success", _language.value)
            }.onFailure {
                _snackBarMessage.value = StringsManager.get("download_error", _language.value)
            }
        }
    }

    fun shareEnhancedVideo() {
        val result = _enhancedResult.value ?: return
        val uri = Uri.parse(result.enhancedVideoUri)
        val file = if (uri.scheme == "file") {
            File(uri.path ?: "")
        } else {
            File(getApplication<Application>().filesDir, "SK_ENHANCED_${result.id.take(8)}.mp4")
        }
        MediaStoreSaver.shareVideo(getApplication(), file)
    }

    fun testBackend() {
        viewModelScope.launch {
            _backendStatus.value = "Testing connection to ${_backendUrl.value}..."
            val result = RemoteEnhancerClient.testServerHealth(_backendUrl.value)
            result.onSuccess { health ->
                _backendStatus.value = "Connected! Device: ${health.device}, Model: ${health.modelName}, FFmpeg: ${if (health.ffmpegAvailable) "Ready" else "Missing"}"
            }.onFailure { err ->
                _backendStatus.value = "Failed: ${err.localizedMessage ?: "Connection error"}"
            }
        }
    }

    fun deleteHistoryItem(id: String) {
        viewModelScope.launch {
            dao.deleteById(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            dao.clearAll()
            _snackBarMessage.value = StringsManager.get("history_cleared", _language.value)
        }
    }
}
