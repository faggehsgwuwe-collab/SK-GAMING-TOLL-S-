package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = ElectricBlue,
    onPrimary = Color.Black,
    primaryContainer = DeepElectricBlue,
    onPrimaryContainer = Color.White,
    secondary = VibrantPurple,
    onSecondary = Color.White,
    secondaryContainer = DeepViolet,
    onSecondaryContainer = Color.White,
    tertiary = NeonCyan,
    onTertiary = Color.Black,
    background = CyberBlack,
    onBackground = TextPrimary,
    surface = SurfaceNavy,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceCard,
    onSurfaceVariant = TextSecondary,
    outline = SurfaceGlassBorder,
    error = ErrorRed,
    onError = Color.White
)

@Composable
fun SKVideoEnhancerTheme(
    darkTheme: Boolean = true, // Default to deep black gaming theme
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
