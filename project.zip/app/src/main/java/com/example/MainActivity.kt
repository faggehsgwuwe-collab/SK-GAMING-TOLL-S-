package com.example

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextWhite

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainScreen(
                    onRequestOverlayPermission = { requestOverlayPermission() },
                    onStartFloatingTool = { startFloatingToolService() },
                    onStopFloatingTool = { stopFloatingToolService() },
                    onOpenPipCompanion = {
                        startActivity(Intent(this, PipGamingCompanionActivity::class.java))
                    }
                )
            }
        }
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            Toast.makeText(this, "Enable 'Allow display over other apps' for SK Gaming Tool", Toast.LENGTH_LONG).show()
        }
    }

    private fun startFloatingToolService() {
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission()
            return
        }

        val serviceIntent = Intent(this, FloatingGamingToolService::class.java).apply {
            action = FloatingGamingToolService.ACTION_START
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
        Toast.makeText(this, "SK Gaming Tool floating button is now active!", Toast.LENGTH_SHORT).show()
    }

    private fun stopFloatingToolService() {
        val serviceIntent = Intent(this, FloatingGamingToolService::class.java).apply {
            action = FloatingGamingToolService.ACTION_STOP
        }
        startService(serviceIntent)
        Toast.makeText(this, "SK Gaming Tool stopped", Toast.LENGTH_SHORT).show()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    onRequestOverlayPermission: () -> Unit,
    onStartFloatingTool: () -> Unit,
    onStopFloatingTool: () -> Unit,
    onOpenPipCompanion: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var selectedTab by remember { mutableIntStateOf(0) }
    var hasOverlayPermission by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    var hasNotificationPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        )
    }

    val isServiceRunning by FloatingGamingToolService.isRunning.collectAsState()

    // Notification launcher for Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasNotificationPermission = granted
        if (granted) {
            Toast.makeText(context, "Notification permission enabled", Toast.LENGTH_SHORT).show()
        }
    }

    // Refresh permission states on resume
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasOverlayPermission = Settings.canDrawOverlays(context)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    hasNotificationPermission = ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) == PackageManager.PERMISSION_GRANTED
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(if (isServiceRunning) NeonGreen else NeonRed)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "SK GAMING TOOL",
                                fontWeight = FontWeight.Black,
                                fontSize = 17.sp,
                                letterSpacing = 0.5.sp,
                                color = NeonGreen
                            )
                            Text(
                                text = if (isServiceRunning) "OVERLAY ACTIVE" else "IDLE • READY FOR FREE FIRE",
                                fontSize = 10.sp,
                                color = if (isServiceRunning) NeonGreen else TextSecondary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface,
                    titleContentColor = NeonGreen
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = DarkSurface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                    label = { Text("Dashboard", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = NeonGreen,
                        indicatorColor = NeonGreen,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Tune, contentDescription = "Sensitivity") },
                    label = { Text("Sens & HUD", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = NeonGreen,
                        indicatorColor = NeonGreen,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Info, contentDescription = "Multi-Window") },
                    label = { Text("OS Truth", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = NeonGreen,
                        indicatorColor = NeonGreen,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.Code, contentDescription = "GitHub APK") },
                    label = { Text("GitHub APK", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = NeonGreen,
                        indicatorColor = NeonGreen,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
            }
        },
        containerColor = DarkBackground
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (selectedTab) {
                0 -> DashboardTab(
                    hasOverlayPermission = hasOverlayPermission,
                    hasNotificationPermission = hasNotificationPermission,
                    isServiceRunning = isServiceRunning,
                    onRequestOverlay = onRequestOverlayPermission,
                    onRequestNotification = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    },
                    onStartTool = onStartFloatingTool,
                    onStopTool = onStopFloatingTool,
                    onOpenPip = onOpenPipCompanion
                )
                1 -> SensitivityAndHudTab(onOpenPip = onOpenPipCompanion)
                2 -> MultiWindowExplainerTab()
                3 -> GitHubActionsGuideTab()
            }
        }
    }
}

@Composable
fun DashboardTab(
    hasOverlayPermission: Boolean,
    hasNotificationPermission: Boolean,
    isServiceRunning: Boolean,
    onRequestOverlay: () -> Unit,
    onRequestNotification: () -> Unit,
    onStartTool: () -> Unit,
    onStopTool: () -> Unit,
    onOpenPip: () -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Master Switch Card
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, if (isServiceRunning) NeonGreen else Color(0xFF202C3C), RoundedCornerShape(20.dp))
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "FLOATING GAMING TOOLBOX",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black,
                            color = NeonGreen
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isServiceRunning)
                                "Floating button active over Free Fire and all apps"
                            else
                                "Enable to show movable floating button & toolbox",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                    Switch(
                        checked = isServiceRunning,
                        onCheckedChange = { checked ->
                            if (checked) {
                                if (!hasOverlayPermission) {
                                    onRequestOverlay()
                                } else {
                                    onStartTool()
                                }
                            } else {
                                onStopTool()
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.Black,
                            checkedTrackColor = NeonGreen,
                            uncheckedThumbColor = TextSecondary,
                            uncheckedTrackColor = Color(0xFF223042)
                        ),
                        modifier = Modifier.testTag("master_tool_switch")
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            if (!hasOverlayPermission) {
                                onRequestOverlay()
                            } else {
                                onStartTool()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonGreen,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("start_overlay_btn")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Start Overlay", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    if (isServiceRunning) {
                        OutlinedButton(
                            onClick = onStopTool,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonRed),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("stop_overlay_btn")
                        ) {
                            Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Stop Overlay", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        // Permissions Status Section
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "System Permissions & Prerequisites",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Overlay Permission Row
                PermissionItemRow(
                    title = "Display over other apps",
                    description = "Required to keep floating button movable over Free Fire",
                    isGranted = hasOverlayPermission,
                    onGrantClick = onRequestOverlay,
                    testTag = "grant_overlay_permission_btn"
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Notification Permission Row (Android 13+)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    PermissionItemRow(
                        title = "Notifications (Android 13+)",
                        description = "Required for persistent foreground service & unhide controls",
                        isGranted = hasNotificationPermission,
                        onGrantClick = onRequestNotification,
                        testTag = "grant_notification_permission_btn"
                    )
                }
            }
        }

        // Quick Launch Shortcuts Card
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Quick App Launchers",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Test launching apps directly or through floating toolbox:",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickAppChip(
                        name = "Free Fire",
                        color = Color(0xFFFF5500),
                        onClick = {
                            AppLauncherHelper.launchAppOrFallback(
                                context,
                                AppLauncherHelper.PKG_FREE_FIRE,
                                "https://ff.garena.com",
                                "Free Fire"
                            )
                        }
                    )
                    QuickAppChip(
                        name = "WhatsApp",
                        color = Color(0xFF25D366),
                        onClick = {
                            AppLauncherHelper.launchAppOrFallback(
                                context,
                                AppLauncherHelper.PKG_WHATSAPP,
                                "https://web.whatsapp.com",
                                "WhatsApp"
                            )
                        }
                    )
                    QuickAppChip(
                        name = "YouTube",
                        color = Color(0xFFFF0000),
                        onClick = {
                            AppLauncherHelper.launchAppOrFallback(
                                context,
                                AppLauncherHelper.PKG_YOUTUBE,
                                "https://m.youtube.com",
                                "YouTube"
                            )
                        }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickAppChip(
                        name = "Messenger",
                        color = Color(0xFF0084FF),
                        onClick = {
                            AppLauncherHelper.launchAppOrFallback(
                                context,
                                AppLauncherHelper.PKG_MESSENGER,
                                "https://m.me",
                                "Messenger"
                            )
                        }
                    )
                    QuickAppChip(
                        name = "Chrome",
                        color = Color(0xFF00E5FF),
                        onClick = {
                            AppLauncherHelper.launchAppOrFallback(
                                context,
                                AppLauncherHelper.PKG_CHROME,
                                "https://www.google.com",
                                "Chrome"
                            )
                        }
                    )
                    QuickAppChip(
                        name = "Discord",
                        color = Color(0xFF5865F2),
                        onClick = {
                            AppLauncherHelper.launchAppOrFallback(
                                context,
                                AppLauncherHelper.PKG_DISCORD,
                                "https://discord.com",
                                "Discord"
                            )
                        }
                    )
                }
            }
        }

        // Picture-in-Picture Companion Card
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "📺 Picture-in-Picture Tactical Mode",
                        color = Color(0xFF00E5FF),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Launch a secondary floating PiP window with safe zone countdown and weapon damage stats while playing Free Fire.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onOpenPip,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF), contentColor = Color.Black),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Open PiP Tactical Window", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Anti-Ban & Fair Play Security Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1A15)),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF1E4B33), RoundedCornerShape(18.dp))
        ) {
            Row(modifier = Modifier.padding(16.dp)) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = NeonGreen,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "100% Anti-Ban & Fair Play Compliant",
                        color = NeonGreen,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "SK GAMING TOOL is strictly an external Android overlay utility. It never touches Free Fire game files, does not inject code, and does not automate gameplay. Completely safe for Free Fire & Free Fire MAX IDs.",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun PermissionItemRow(
    title: String,
    description: String,
    isGranted: Boolean,
    onGrantClick: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF182330), RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.Warning,
                    contentDescription = null,
                    tint = if (isGranted) NeonGreen else NeonRed,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = description,
                color = TextSecondary,
                fontSize = 10.sp
            )
        }

        if (isGranted) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF003B17))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "Granted",
                    color = NeonGreen,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        } else {
            Button(
                onClick = onGrantClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonRed,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag(testTag)
            ) {
                Text("Enable", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun QuickAppChip(name: String, color: Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF182330))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text(text = name, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SensitivityAndHudTab(onOpenPip: () -> Unit) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "🎯 Pro Free Fire Drag-Headshot Sensitivity",
                    color = NeonGreen,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "Calibrated for 2GB - 12GB RAM Android phones for ultra-smooth drag headshots",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(14.dp))

                SensitivityRow("General (Screen Look)", "98 - 100", "Critical for fast drag & rotation")
                SensitivityRow("Red Dot Sight", "94 - 98", "Perfect for non-scope head drag")
                SensitivityRow("2X Scope", "92 - 96", "Ideal for mid-range Woodpecker/M4A1")
                SensitivityRow("4X Scope", "88 - 92", "Stable spray headshots on SCAR/Groza")
                SensitivityRow("Sniper Scope (AWM/M82B)", "55 - 65", "Controlled flick-shot precision")
                SensitivityRow("Free Look", "70 - 80", "Quick situational scanning")
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "⚙️ Recommended Phone DPI Settings",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "• 2GB - 4GB RAM Devices: Default DPI + 40 (Max 420 DPI)\n• 6GB - 8GB RAM Devices: 440 - 480 DPI\n• 12GB+ Gaming Devices: 500 DPI (High touch sampling rate)",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Tip: Change DPI safely in Android Developer Options > Smallest Width. Do not increase beyond +100 of default to avoid UI crashes.",
                    color = Color(0xFFFFB300),
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun SensitivityRow(title: String, value: String, hint: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .background(Color(0xFF182330), RoundedCornerShape(10.dp))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(text = hint, color = TextSecondary, fontSize = 10.sp)
        }
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF003B17))
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Text(text = value, color = NeonGreen, fontSize = 13.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
fun MultiWindowExplainerTab() {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.5.dp, Color(0xFFFFB300), RoundedCornerShape(18.dp))
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "⚠️ The Android OS Truth on Floating Apps",
                    color = Color(0xFFFFB300),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Why 'Display over other apps' does NOT allow other apps to run in mini floating bubbles:",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "1. Security Sandbox: In Android, granting 'Display over other apps' (SYSTEM_ALERT_WINDOW) only grants permission for SK GAMING TOOL to render its own views on screen.\n\n" +
                            "2. Task Stack Isolation: Android security prevents any third-party app from embedding or forcing external apps (like WhatsApp, YouTube, or Messenger) into custom floating view frames without system-level window tokens.\n\n" +
                            "3. OEM Custom Features: Floating mini-windows for other apps only exist if the phone manufacturer built them into the operating system (e.g. Xiaomi MIUI Game Turbo floating windows, Samsung One UI Pop-up view, or OnePlus Gaming Tools).",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "💡 How to Use True Multi-Window with Free Fire",
                    color = NeonGreen,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Method 1: Android Native Split-Screen Mode\n" +
                            "• Open Free Fire.\n" +
                            "• Swipe up to open Android Recent Apps / App Switcher.\n" +
                            "• Tap the Free Fire app icon at the top of the card.\n" +
                            "• Select 'Split top' or 'Split Screen'.\n" +
                            "• Choose WhatsApp, YouTube, or Chrome as the second app!\n\n" +
                            "Method 2: Android Developer Freeform Mode\n" +
                            "• Go to phone Settings > About Phone > Tap 'Build Number' 7 times.\n" +
                            "• Open System > Developer Options.\n" +
                            "• Scroll down and turn ON 'Force activities to be resizable' and 'Enable freeform windows'.\n" +
                            "• Restart your phone. Now in Recents, tapping any app icon gives a 'Freeform Window' option!",
                    color = Color(0xFFE0E0E0),
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

@Composable
fun GitHubActionsGuideTab() {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "🚀 GitHub Actions Android APK Build Guide",
                    color = NeonGreen,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "How to push this project to GitHub from your Android phone and download the generated Debug APK:",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(14.dp))

                StepCard(
                    number = "1",
                    title = "Export or Push Code from AI Studio",
                    desc = "In AI Studio on your phone browser, open project settings and select 'Push to GitHub' or download the project ZIP."
                )

                StepCard(
                    number = "2",
                    title = "GitHub Actions Workflow Included",
                    desc = "This project already includes '.github/workflows/build-apk.yml'. As soon as you push code to GitHub, GitHub Actions will automatically start building the APK."
                )

                StepCard(
                    number = "3",
                    title = "Download the Generated APK on Phone",
                    desc = "1. Open your repository on GitHub (chrome or mobile app).\n" +
                            "2. Tap the 'Actions' tab.\n" +
                            "3. Tap the latest workflow run ('Build Android Debug APK').\n" +
                            "4. Scroll down to 'Artifacts' and tap 'sk-gaming-tool-debug-apk.zip'.\n" +
                            "5. Extract the ZIP on your phone and install the APK!"
                )

                StepCard(
                    number = "4",
                    title = "Uploading from Phone with Spck Editor or Termux",
                    desc = "If editing files directly on Android, use Spck Editor or Termux: git init -> git remote add origin <repo_url> -> git add . -> git commit -m 'Initial commit' -> git push -u origin main."
                )
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF15202E)),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Workflow File Location",
                    color = Color(0xFF00E5FF),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = ".github/workflows/build-apk.yml",
                    fontFamily = FontFamily.Monospace,
                    color = NeonGreen,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Pre-configured with JDK 17, Gradle caching, assembleDebug task, and automatic artifact uploading.",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun StepCard(number: String, title: String, desc: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .background(Color(0xFF182330), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(26.dp)
                .clip(CircleShape)
                .background(NeonGreen),
            contentAlignment = Alignment.Center
        ) {
            Text(text = number, color = Color.Black, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(text = title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = desc, color = TextSecondary, fontSize = 11.sp, lineHeight = 16.sp)
        }
    }
}
