package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AppLanguage
import com.example.data.model.EnhancementOptions
import com.example.data.model.UpscaleFactor
import com.example.util.StringsManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read app_name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("SK Video Enhancer", appName)
    }

    @Test
    fun `verify bilingual strings for English and Bengali`() {
        val enTitle = StringsManager.get("app_title", AppLanguage.ENGLISH)
        val bnTitle = StringsManager.get("app_title", AppLanguage.BENGALI)

        assertEquals("SK VIDEO ENHANCER", enTitle)
        assertEquals("এসকে ভিডিও এনহ্যান্সার", bnTitle)
    }

    @Test
    fun `verify official watermark configuration`() {
        val options = EnhancementOptions()
        assertEquals("SK MUZAMMEL 10K", options.watermarkText)
        assertTrue(options.watermarkOpacity in 0.20f..0.30f)
    }
}
