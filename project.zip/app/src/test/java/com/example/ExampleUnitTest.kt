package com.example

import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testPackageConstants() {
    assertEquals("com.dts.freefireth", AppLauncherHelper.PKG_FREE_FIRE)
    assertEquals("com.whatsapp", AppLauncherHelper.PKG_WHATSAPP)
    assertEquals("com.google.android.youtube", AppLauncherHelper.PKG_YOUTUBE)
    assertEquals("com.facebook.orca", AppLauncherHelper.PKG_MESSENGER)
    assertEquals("com.android.chrome", AppLauncherHelper.PKG_CHROME)
    assertEquals("com.discord", AppLauncherHelper.PKG_DISCORD)
  }
}
